/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { Store } from '../types';
import { MapPin, Phone, Clock, Navigation, ExternalLink, Star } from 'lucide-react';

interface StoreCardProps {
  key?: string;
  store: Store;
  isSelected: boolean;
  onSelect: () => void;
  onGetDirections?: () => void;
  onMouseEnter?: () => void;
  onMouseLeave?: () => void;
}

export default function StoreCard({ store, isSelected, onSelect, onGetDirections, onMouseEnter, onMouseLeave }: StoreCardProps) {
  return (
    <div
      onClick={onSelect}
      onMouseEnter={onMouseEnter}
      onMouseLeave={onMouseLeave}
      className={`group relative bg-white border rounded-2xl overflow-hidden transition-all duration-300 cursor-pointer flex flex-col justify-between ${
        isSelected
          ? 'border-brand-green-600 ring-2 ring-brand-green-100 shadow-md transform -translate-y-0.5'
          : 'border-stone-200 hover:border-stone-300 hover:shadow-md'
      }`}
    >
      {/* Featured Star Floating Badge */}
      {store.featured && (
        <div className="absolute top-3 left-3 z-10 bg-brand-gold-500 text-stone-900 text-[10px] font-bold px-2.5 py-1 rounded-full shadow-md flex items-center space-x-1 border border-brand-gold-600/20">
          <Star className="w-3 h-3 fill-stone-900" />
          <span>Flagship Outlet</span>
        </div>
      )}

      {/* Region Badge */}
      <div className="absolute top-3 right-3 z-10 bg-stone-900/85 backdrop-blur-sm text-stone-100 text-[9px] font-black tracking-widest uppercase px-2 py-0.5 rounded border border-stone-700/50">
        {store.region}
      </div>

      <div className="flex flex-col sm:flex-row md:flex-col lg:flex-row h-full">
        {/* Cover Photo */}
        <div className="relative w-full sm:w-40 md:w-full lg:w-44 h-40 sm:h-auto md:h-40 lg:h-auto bg-stone-100 overflow-hidden flex-shrink-0">
          <img
            src={store.image}
            alt={store.storeName}
            referrerPolicy="no-referrer"
            loading="lazy"
            className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
          />
        </div>

        {/* Info */}
        <div className="p-5 flex-1 flex flex-col justify-between space-y-4">
          <div className="space-y-1.5">
            <div className="flex items-center space-x-1 text-[11px] font-bold text-brand-green-700 uppercase tracking-widest">
              <MapPin className="w-3.5 h-3.5" />
              <span>{store.city}</span>
            </div>
            <h4 className="font-heading font-semibold text-[15px] text-stone-900 leading-tight group-hover:text-brand-green-700 transition-colors">
              {store.storeName}
            </h4>
            <p className="text-xs text-stone-500 leading-relaxed font-sans line-clamp-2">
              {store.address}
            </p>
          </div>

          {/* Quick info grid */}
          <div className="space-y-1.5 text-stone-600 font-sans pr-2">
            <div className="flex items-center space-x-2 text-xs">
              <Phone className="w-3.5 h-3.5 text-stone-400 flex-shrink-0" />
              <span className="truncate">{store.phone}</span>
            </div>
            <div className="flex items-center space-x-2 text-xs">
              <Clock className="w-3.5 h-3.5 text-stone-400 flex-shrink-0" />
              <span className="truncate">{store.hours}</span>
            </div>
          </div>

          {/* Tags */}
          {store.tags && store.tags.length > 0 && (
            <div className="flex flex-wrap gap-1 pt-1">
              {store.tags.slice(0, 2).map((tag, idx) => (
                <span
                  key={idx}
                  className="bg-brand-beige-100 text-stone-600 text-[9px] font-semibold px-2 py-0.5 rounded-full"
                >
                  {tag}
                </span>
              ))}
            </div>
          )}

          {/* Action CTAs */}
          <div className="flex items-center space-x-2 pt-2 border-t border-stone-100" onClick={(e) => e.stopPropagation()}>
            <a
              href={`tel:${store.phone.replace(/\s+/g, '')}`}
              className="flex-shrink-0 px-2.5 py-1.5 rounded-lg border border-stone-200 text-xs font-semibold text-stone-700 hover:bg-stone-50 transition-colors"
              title="Call Store"
            >
              Call Us
            </a>
            <button
              onClick={onGetDirections}
              className="flex-1 inline-flex items-center justify-center space-x-1.5 bg-brand-green-50 hover:bg-brand-green-100 text-brand-green-800 text-xs font-bold py-1.5 px-3 rounded-lg transition-colors border border-brand-green-200/50"
            >
              <Navigation className="w-3 h-3 fill-brand-green-800" />
              <span>Navigate</span>
            </button>
            <a
              href={store.googleMapsLink}
              target="_blank"
              rel="noopener sans-referrer"
              className="px-2.5 py-1.5 bg-stone-900 hover:bg-stone-800 text-white rounded-lg transition-colors"
              title="View in Google Maps"
            >
              <ExternalLink className="w-3.5 h-3.5" />
            </a>
          </div>
        </div>
      </div>
    </div>
  );
}
