/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useEffect, useRef, useState } from 'react';
import L from 'leaflet';
import { Store, UserLocation } from '../types';
import { Locate, Navigation, MapPin, Map, X } from 'lucide-react';

interface StoreTypeInfo {
  type: 'flagship' | 'market' | 'authorized';
  color: string;
  ringColor: string;
  bgClass: string;
  borderClass: string;
  label: string;
  accentColor: string;
}

const STORE_TYPES: { [key in 'flagship' | 'market' | 'authorized']: StoreTypeInfo } = {
  flagship: {
    type: 'flagship',
    color: '#D97706', // Gold/Amber
    ringColor: '#F59E0B',
    bgClass: 'bg-amber-600',
    borderClass: 'border-amber-600',
    label: 'Flagship & Hubs',
    accentColor: 'text-amber-600'
  },
  market: {
    type: 'market',
    color: '#0284C7', // Sky blue
    ringColor: '#38BDF8',
    bgClass: 'bg-sky-600',
    borderClass: 'border-sky-600',
    label: 'Market Stalls',
    accentColor: 'text-sky-600'
  },
  authorized: {
    type: 'authorized',
    color: '#16A34A', // Brand Green
    ringColor: '#22C55E',
    bgClass: 'bg-brand-green-600',
    borderClass: 'border-brand-green-600',
    label: 'Authorized Outlets',
    accentColor: 'text-brand-green-600'
  }
};

const getStoreType = (store: Store): StoreTypeInfo => {
  const tags = store.tags || [];
  if (store.featured || tags.some(t => t.includes('Primary') || t.includes('Hub') || t.includes('Central') || t.includes('Circle') || t.includes('Gateway') || t.includes('Metro'))) {
    return STORE_TYPES.flagship;
  }
  if (tags.some(t => t.toLowerCase().includes('market') || t.toLowerCase().includes('stall'))) {
    return STORE_TYPES.market;
  }
  return STORE_TYPES.authorized;
};

interface StoreMapProps {
  stores: Store[];
  selectedStore: Store | null;
  onStoreSelect: (store: Store) => void;
  mapTheme: 'light' | 'warm' | 'dark';
  hoveredStoreId: string | null;
  onStoreHover?: (storeId: string | null) => void;
}

export default function StoreMap({
  stores,
  selectedStore,
  onStoreSelect,
  mapTheme,
  hoveredStoreId,
  onStoreHover
}: StoreMapProps) {
  const mapContainerRef = useRef<HTMLDivElement>(null);
  const mapRef = useRef<L.Map | null>(null);
  const markersRef = useRef<{ [key: string]: L.Marker }>({});
  const userMarkerRef = useRef<L.Marker | null>(null);
  const tileLayerRef = useRef<L.TileLayer | null>(null);

  const [userLoc, setUserLoc] = useState<UserLocation | null>(null);
  const [nearestStore, setNearestStore] = useState<Store | null>(null);
  const [isLocating, setIsLocating] = useState(false);
  const [isMobile, setIsMobile] = useState(false);
  const [isMapActive, setIsMapActive] = useState(false);
  const [showNearestCard, setShowNearestCard] = useState(true);

  // Detect mobile viewport to toggle scroll past protection
  useEffect(() => {
    const checkMobile = () => {
      setIsMobile(window.innerWidth < 768);
    };
    checkMobile();
    window.addEventListener('resize', checkMobile);
    return () => window.removeEventListener('resize', checkMobile);
  }, []);

  // Dynamically enable/disable Leaflet interactions based on lock/active state on mobile
  useEffect(() => {
    const map = mapRef.current;
    if (!map) return;

    if (isMobile && !isMapActive) {
      map.dragging.disable();
      map.scrollWheelZoom.disable();
      map.touchZoom.disable();
      map.doubleClickZoom.disable();
    } else {
      map.dragging.enable();
      map.scrollWheelZoom.enable();
      map.touchZoom.enable();
      map.doubleClickZoom.enable();
    }
  }, [isMobile, isMapActive]);

  // Helper: Haversine Formula for distance calculation (PH Archipelago geography friendly)
  const calculateDistance = (lat1: number, lon1: number, lat2: number, lon2: number): number => {
    const R = 6371; // Earth radius in km
    const dLat = ((lat2 - lat1) * Math.PI) / 180;
    const dLon = ((lon2 - lon1) * Math.PI) / 180;
    const a =
      Math.sin(dLat / 2) * Math.sin(dLat / 2) +
      Math.cos((lat1 * Math.PI) / 180) *
        Math.cos((lat2 * Math.PI) / 180) *
        Math.sin(dLon / 2) *
        Math.sin(dLon / 2);
    const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
    return R * c; // Distance in km
  };

  // 1. Initialize Map
  useEffect(() => {
    if (!mapContainerRef.current || mapRef.current) return;

    // Center of Philippines archipelago
    const PH_CENTER: [number, number] = [12.8797, 121.7740];
    const initialZoom = 6;

    // Create Leaflet map instance
    const map = L.map(mapContainerRef.current, {
      zoomControl: false,
      scrollWheelZoom: true,
      attributionControl: true
    }).setView(PH_CENTER, initialZoom);

    // Save map reference
    mapRef.current = map;

    // Add standard Zoom Control on the right side
    const isMobileDevice = window.innerWidth < 768;
    L.control.zoom({ position: isMobileDevice ? 'bottomright' : 'topright' }).addTo(map);

    return () => {
      if (mapRef.current) {
        mapRef.current.remove();
        mapRef.current = null;
      }
    };
  }, []);

  // 2. Load Tile Layer according to Theme selection
  useEffect(() => {
    const map = mapRef.current;
    if (!map) return;

    // Remove existing tile layer
    if (tileLayerRef.current) {
      tileLayerRef.current.remove();
    }

    let tileUrl = '';
    let attribution = '';

    if (mapTheme === 'dark') {
      tileUrl = 'https://{s}.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}{r}.png';
      attribution = '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors &copy; <a href="https://carto.com/attributions">CARTO</a>';
    } else if (mapTheme === 'warm') {
      tileUrl = 'https://{s}.basemaps.cartocdn.com/rastertiles/voyager/{z}/{x}/{y}{r}.png';
      attribution = '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors &copy; <a href="https://carto.com/attributions">CARTO</a>';
    } else {
      // Light
      tileUrl = 'https://{s}.basemaps.cartocdn.com/light_all/{z}/{x}/{y}{r}.png';
      attribution = '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors &copy; <a href="https://carto.com/attributions">CARTO</a>';
    }

    const tileLayer = L.tileLayer(tileUrl, {
      attribution,
      maxZoom: 19
    }).addTo(map);

    tileLayerRef.current = tileLayer;
  }, [mapTheme]);

  // 3. Render Custom Store Pins & Clusters
  useEffect(() => {
    const map = mapRef.current;
    if (!map) return;

    // Clear old markers from map
    (Object.values(markersRef.current) as L.Marker[]).forEach((marker) => marker.remove());
    markersRef.current = {};

    stores.forEach((store) => {
      // Create beautifully styled Leaflet customized HTML markers
      const isCurrentlySelected = selectedStore?.id === store.id;
      const isCurrentlyHovered = hoveredStoreId === store.id;
      const hasCoords = typeof store.lat === 'number' && typeof store.lng === 'number' && store.lat !== 0 && store.lng !== 0;

      const typeInfo = getStoreType(store);

      const customIconHtml = `
        <div class="custom-marker-wrapper" data-store-id="${store.id}" style="--marker-color: ${typeInfo.color}; --marker-ring-color: ${typeInfo.color}66;">
          <div class="custom-marker-ring ${isCurrentlyHovered ? 'hovered' : ''}"></div>
          <div class="custom-marker-pin ${isCurrentlySelected ? 'active animate-[pin-bounce_2s_infinite]' : ''} ${isCurrentlyHovered ? 'hovered' : ''}">
            <div class="custom-marker-icon">
              <svg xmlns="http://www.w3.org/2000/svg" width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round" stroke-linejoin="round">
                <path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/>
              </svg>
            </div>
          </div>
        </div>
      `;

      const markerIcon = L.divIcon({
        html: customIconHtml,
        className: 'custom-div-icon',
        iconSize: [44, 44],
        iconAnchor: [22, 38] // Pins aligned precisely with coords
      });

      // HTML custom popup details panel
      const popupHtml = `
        <div class="font-sans text-stone-800" style="width: 290px;">
          <div class="relative h-32 bg-stone-100 rounded-t-xl overflow-hidden">
            <img src="${store.image}" alt="${store.storeName}" class="w-full h-full object-cover" referrerpolicy="no-referrer" />
            <div class="absolute top-2.5 right-2.5 bg-stone-900 text-white text-[9px] font-bold px-2 py-0.5 rounded tracking-wide uppercase">
              ${store.region}
            </div>
          </div>
          <div class="p-4 space-y-3 bg-white rounded-b-xl border-t border-stone-100">
            <div>
              <h4 class="font-heading font-semibold text-[14px] text-stone-900 leading-tight">${store.storeName}</h4>
              <p class="text-[11px] text-stone-500 mt-0.5 leading-relaxed">${store.address}</p>
            </div>
            <div class="space-y-1 text-stone-600 text-xs">
              <div class="flex items-center space-x-1.5">
                <svg xmlns="http://www.w3.org/2000/svg" width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="text-stone-400 flex-shrink-0">
                  <path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72 12.84 12.84 0 0 0 .7 2.81 2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45 12.84 12.84 0 0 0 2.81.7A2 2 0 0 1 22 16.92z"/>
                </svg>
                <span>${store.phone}</span>
              </div>
              <div class="flex items-center space-x-1.5">
                <svg xmlns="http://www.w3.org/2000/svg" width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="text-stone-400 flex-shrink-0">
                  <circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/>
                </svg>
                <span>${store.hours}</span>
              </div>
            </div>
            <div class="pt-2 border-t border-stone-150 flex flex-col gap-1.5">
              <div class="flex items-center gap-2">
                <a href="${store.googleMapsLink}" target="_blank" rel="noopener" class="flex-1 text-center bg-brand-green-700 hover:bg-brand-green-800 text-white font-semibold text-[11px] py-1.5 px-3 rounded-lg shadow-sm transition-colors flex items-center justify-center space-x-1">
                  <svg xmlns="http://www.w3.org/2000/svg" width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" class="inline">
                    <polygon points="3 6 9 3 15 6 21 3 21 18 15 21 9 18 3 21"/>
                    <line x1="9" y1="3" x2="9" y2="18"/>
                    <line x1="15" y1="6" x2="15" y2="21"/>
                  </svg>
                  <span>Open in Maps</span>
                </a>
                <a href="tel:${store.phone.replace(/\s+/g, '')}" class="text-center border border-stone-200 hover:bg-stone-50 text-stone-700 font-semibold text-[11px] py-1.5 px-3 rounded-lg transition-colors flex-shrink-0">
                  Call Store
                </a>
              </div>
              ${hasCoords ? `
                <a href="https://www.google.com/maps/@?api=1&map_action=pano&viewpoint=${store.lat},${store.lng}" target="_blank" rel="noopener" class="text-center bg-stone-900 hover:bg-stone-800 text-white font-semibold text-[10px] py-1.5 px-3 rounded-lg shadow-sm transition-colors flex items-center justify-center space-x-1.5 tracking-wider uppercase">
                  <svg xmlns="http://www.w3.org/2000/svg" width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round" class="inline">
                    <path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/>
                    <circle cx="12" cy="12" r="3"/>
                  </svg>
                  <span>360° Street View</span>
                </a>
              ` : ''}
            </div>
          </div>
        </div>
      `;

      const marker = L.marker([store.lat, store.lng], { icon: markerIcon })
        .addTo(map)
        .bindPopup(popupHtml, {
          closeButton: false,
          offset: L.point(0, -32)
        });

      // Set Selection Action on Click
      marker.on('click', () => {
        onStoreSelect(store);
      });

      // Hover Synchronization: Map to List
      marker.on('mouseover', () => {
        if (onStoreHover) onStoreHover(store.id);
      });
      marker.on('mouseout', () => {
        if (onStoreHover) onStoreHover(null);
      });

      // Store marker reference
      markersRef.current[store.id] = marker;
    });
  }, [stores, selectedStore, hoveredStoreId, onStoreHover]);

  // 4. Focus Map details on selected store change
  useEffect(() => {
    const map = mapRef.current;
    if (!map || !selectedStore) return;

    const marker = markersRef.current[selectedStore.id];
    if (marker) {
      // Pan beautifully
      map.flyTo([selectedStore.lat, selectedStore.lng], 14, {
        animate: true,
        duration: 1.5
      });

      // Delay popup trigger slightly after fly animation begins to look elegant
      setTimeout(() => {
        if (markersRef.current[selectedStore.id] && mapRef.current) {
          markersRef.current[selectedStore.id].openPopup();
        }
      }, 500);
    }
  }, [selectedStore]);

  // 5. User GPS Geolocation Finder
  const handleLocateUser = () => {
    const map = mapRef.current;
    if (!map) return;

    setIsLocating(true);

    navigator.geolocation.getCurrentPosition(
      (position) => {
        const { latitude, longitude } = position.coords;
        const userLocCoordinates: UserLocation = { lat: latitude, lng: longitude };

        setUserLoc(userLocCoordinates);
        setIsLocating(false);

        // Find nearest store in the Philippine database
        if (stores.length > 0) {
          let closest: Store | null = null;
          let minDistance = Infinity;

          stores.forEach((store) => {
            const distance = calculateDistance(latitude, longitude, store.lat, store.lng);
            if (distance < minDistance) {
              minDistance = distance;
              closest = store;
            }
          });

          if (closest) {
            setNearestStore(closest);
            onStoreSelect(closest);
            setShowNearestCard(true);
          }
        }

        // Drop user point tracking marker
        if (userMarkerRef.current) {
          userMarkerRef.current.remove();
        }

        const userIcon = L.divIcon({
          html: `
            <div class="relative w-10 h-10 flex items-center justify-center">
              <span class="absolute inline-flex h-full w-full rounded-full bg-blue-400 opacity-60 animate-ping"></span>
              <span class="relative inline-flex rounded-full h-4.5 w-4.5 bg-blue-600 border-2 border-white shadow-xl"></span>
            </div>
          `,
          className: 'user-location-marker',
          iconSize: [40, 40],
          iconAnchor: [20, 20]
        });

        const userMarker = L.marker([latitude, longitude], { icon: userIcon })
          .addTo(map)
          .bindPopup(`
            <div class="font-sans text-stone-800 p-2 text-center text-xs font-semibold">
              <span class="text-blue-600">Your Current Location</span>
            </div>
          `, { closeButton: false }).openPopup();

        userMarkerRef.current = userMarker;
      },
      (error) => {
        setIsLocating(false);
        console.error('Error obtaining GPS status', error);
        alert('Geolocation could not be accessed. Please ensure browser permissions are enabled.');
      },
      { enableHighAccuracy: true, timeout: 6000 }
    );
  };

  return (
    <div className="relative h-full w-full overflow-hidden rounded-2xl border border-stone-200 bg-stone-100 shadow-md">
      {/* Tap to interact Overlay for Mobile (allows scroll past) */}
      {isMobile && !isMapActive && (
        <div 
          onClick={() => setIsMapActive(true)}
          className="absolute inset-0 z-30 flex flex-col items-center justify-center bg-stone-950/40 backdrop-blur-[2px] transition-all duration-300 cursor-pointer animate-fadeIn"
        >
          <div className="bg-white/95 backdrop-blur-sm border border-stone-200 px-5 py-4 rounded-2xl shadow-xl flex flex-col items-center space-y-2 max-w-[240px] text-center transform hover:scale-105 active:scale-95 transition-all">
            <div className="w-10 h-10 rounded-full bg-brand-green-50 flex items-center justify-center text-brand-green-700 animate-pulse">
              <Map className="w-5 h-5 text-brand-green-700" />
            </div>
            <span className="font-heading font-bold text-xs text-stone-900">Tap to Interact</span>
            <span className="text-[10px] text-stone-500 leading-normal font-sans">
              Activate map to pan, pinch-to-zoom, and explore branches around the country.
            </span>
          </div>
        </div>
      )}

      {/* Leaflet map frame */}
      <div ref={mapContainerRef} className="h-full w-full z-10" />

      {/* Floating unified HUD bar at the top with left/right column structure */}
      <div className="absolute top-3 left-3 right-3 z-40 pointer-events-none flex items-start justify-between gap-3 flex-wrap">
        {/* Left side: Finder elements */}
        <div className="pointer-events-auto flex flex-col gap-2 items-start max-w-[280px]">
          <button
            onClick={handleLocateUser}
            disabled={isLocating}
            className="flex items-center space-x-2 bg-white/95 backdrop-blur-sm hover:bg-white text-stone-800 font-bold text-xs px-4 py-3 rounded-2xl shadow-lg border border-stone-200 hover:border-brand-green-500 transition-all duration-300 disabled:opacity-50 cursor-pointer shadow-stone-800/10"
          >
            <Locate className={`w-4.5 h-4.5 text-brand-green-600 ${isLocating ? 'animate-spin' : ''}`} />
            <span className="whitespace-nowrap">{isLocating ? 'Locating...' : 'Find Nearest Branch'}</span>
          </button>

          {userLoc && nearestStore && showNearestCard && (
            <div className="bg-white/95 backdrop-blur-sm p-4 rounded-2xl shadow-xl border border-stone-200/80 w-64 md:w-72 animate-fadeIn space-y-2 relative shadow-stone-800/10">
              <button
                onClick={() => setShowNearestCard(false)}
                className="absolute top-2 right-2 p-1 text-stone-400 hover:text-stone-600 rounded-full hover:bg-stone-100 transition-colors cursor-pointer"
                aria-label="Close panel"
              >
                <X className="w-4 h-4" />
              </button>

              <div className="flex items-center space-x-1.5 text-brand-green-700 text-[10px] font-bold uppercase tracking-wider pr-4">
                <MapPin className="w-3 h-3 fill-brand-green-200" />
                <span>Closest Herbenna Found!</span>
              </div>
              <div>
                <h5 className="font-heading font-semibold text-xs text-stone-900 leading-tight">
                  {nearestStore.storeName}
                </h5>
                <p className="text-[10px] text-stone-500 leading-tight mt-0.5">
                  Approx. <span className="font-bold text-stone-700">{calculateDistance(userLoc.lat, userLoc.lng, nearestStore.lat, nearestStore.lng).toFixed(1)} km</span> away.
                </p>
              </div>
              <button
                onClick={() => {
                  onStoreSelect(nearestStore!);
                  setIsMapActive(true);
                  const map = mapRef.current;
                  if (map) {
                    map.flyTo([nearestStore!.lat, nearestStore!.lng], 14, {
                      animate: true,
                      duration: 1.2
                    });
                    setTimeout(() => {
                      if (markersRef.current[nearestStore!.id] && mapRef.current) {
                        markersRef.current[nearestStore!.id].openPopup();
                      }
                    }, 400);
                  }
                }}
                className="w-full bg-stone-900 hover:bg-brand-green-700 text-white font-bold text-[10px] py-1.5 rounded-lg transition-colors flex items-center justify-center space-x-1 cursor-pointer"
              >
                <Navigation className="w-2.5 h-2.5 fill-white" />
                <span>Center Marker view</span>
              </button>
            </div>
          )}
        </div>

        {/* Right side: Re-Lock button for active mobile interactions */}
        {isMobile && isMapActive && (
          <div className="pointer-events-auto">
            <button
              onClick={() => setIsMapActive(false)}
              className="flex items-center space-x-1.5 bg-brand-green-700 hover:bg-brand-green-800 text-white font-bold text-[10px] px-3 py-2 rounded-xl shadow-lg transition-all active:scale-95 cursor-pointer uppercase tracking-wider shadow-stone-800/10"
            >
              <Map className="w-3.5 h-3.5" />
              <span>Lock Map Scroll</span>
            </button>
          </div>
        )}
      </div>
    </div>
  );
}
