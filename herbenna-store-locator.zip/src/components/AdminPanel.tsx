/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { Store } from '../types';
import { Plus, Trash2, Edit, Save, X, PlusCircle, ArrowLeft, Star, Settings } from 'lucide-react';

interface AdminPanelProps {
  stores: Store[];
  onAddStore: (store: Omit<Store, 'id'>) => void;
  onUpdateStore: (store: Store) => void;
  onDeleteStore: (id: string) => void;
  onClose: () => void;
}

export default function AdminPanel({
  stores,
  onAddStore,
  onUpdateStore,
  onDeleteStore,
  onClose
}: AdminPanelProps) {
  const [editingStoreId, setEditingStoreId] = useState<string | null>(null);
  const [isAdding, setIsAdding] = useState(false);

  // Form State
  const [storeName, setStoreName] = useState('');
  const [lat, setLat] = useState<number | ''>('');
  const [lng, setLng] = useState<number | ''>('');
  const [address, setAddress] = useState('');
  const [phone, setPhone] = useState('');
  const [hours, setHours] = useState('10:00 AM - 9:00 PM');
  const [image, setImage] = useState('');
  const [googleMapsLink, setGoogleMapsLink] = useState('');
  const [region, setRegion] = useState<'Luzon' | 'Visayas' | 'Mindanao'>('Luzon');
  const [city, setCity] = useState('');
  const [tagsText, setTagsText] = useState('');
  const [featured, setFeatured] = useState(false);

  const startEdit = (store: Store) => {
    setEditingStoreId(store.id);
    setIsAdding(false);
    setStoreName(store.storeName);
    setLat(store.lat);
    setLng(store.lng);
    setAddress(store.address);
    setPhone(store.phone);
    setHours(store.hours);
    setImage(store.image);
    setGoogleMapsLink(store.googleMapsLink);
    setRegion(store.region);
    setCity(store.city);
    setTagsText(store.tags ? store.tags.join(', ') : '');
    setFeatured(store.featured || false);
  };

  const startAdd = () => {
    setIsAdding(true);
    setEditingStoreId(null);
    setStoreName('');
    setLat(14.5995); // Default Manila
    setLng(120.9842);
    setAddress('');
    setPhone('');
    setHours('10:00 AM - 9:00 PM');
    setImage('');
    setGoogleMapsLink('');
    setRegion('Luzon');
    setCity('');
    setTagsText('Herbal Consultation, Full Stock');
    setFeatured(false);
  };

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    if (!storeName || lat === '' || lng === '' || !address || !phone || !city) {
      alert('Please fill out all required fields marked with *');
      return;
    }

    const tagsArray = tagsText
      ? tagsText.split(',').map((t) => t.trim()).filter(Boolean)
      : [];

    const finalLat = Number(lat);
    const finalLng = Number(lng);
    const finalImage = image && !image.includes('picsum.photos') && !image.includes('unsplash.com')
      ? image
      : `https://static-maps.yandex.ru/1.x/?lang=en_US&ll=${finalLng},${finalLat}&z=15&l=map&size=450,300&pt=${finalLng},${finalLat},pm2rdm`;

    const storeData = {
      storeName,
      lat: finalLat,
      lng: finalLng,
      address,
      phone,
      hours,
      image: finalImage,
      googleMapsLink: googleMapsLink || `https://maps.google.com/?q=${encodeURIComponent(storeName)}`,
      region,
      city,
      tags: tagsArray,
      featured
    };

    if (editingStoreId) {
      onUpdateStore({
        id: editingStoreId,
        ...storeData
      });
      setEditingStoreId(null);
    } else if (isAdding) {
      onAddStore(storeData);
      setIsAdding(false);
    }
  };

  return (
    <div className="bg-stone-50 border border-stone-200 rounded-2xl p-6 shadow-lg">
      <div className="flex items-center justify-between border-b border-stone-200 pb-4 mb-5">
        <div className="flex items-center space-x-2">
          <Settings className="w-5 h-5 text-brand-green-700 animate-pulse" />
          <h3 className="font-heading font-semibold text-lg text-stone-900">Branch Management Console</h3>
        </div>
        <button
          onClick={onClose}
          className="text-stone-400 hover:text-stone-700 p-1 rounded-full hover:bg-stone-100 transition-colors"
        >
          <X className="w-5 h-5" />
        </button>
      </div>

      {isAdding || editingStoreId ? (
        <form onSubmit={handleSave} className="space-y-4">
          <div className="flex items-center space-x-2 text-brand-green-700 hover:text-brand-green-800 font-semibold text-sm cursor-pointer mb-2" onClick={() => { setIsAdding(false); setEditingStoreId(null); }}>
            <ArrowLeft className="w-4 h-4" />
            <span>Back to Store List</span>
          </div>

          <h4 className="font-heading font-semibold text-sm text-stone-800 border-b border-stone-100 pb-2">
            {editingStoreId ? 'Edit Branch Details' : 'Add New Branch'}
          </h4>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-bold uppercase text-stone-700 mb-1" htmlFor="admin-store-name">
                Store Name *
              </label>
              <input
                id="admin-store-name"
                type="text"
                value={storeName}
                onChange={(e) => setStoreName(e.target.value)}
                className="w-full px-3 py-2 border border-stone-200 bg-white rounded-lg focus:outline-none focus:ring-1 focus:ring-brand-green-600 text-sm"
                placeholder="Herbenna Manila Premium"
                required
              />
            </div>
            <div>
              <label className="block text-xs font-bold uppercase text-stone-700 mb-1" htmlFor="admin-city">
                City *
              </label>
              <input
                id="admin-city"
                type="text"
                value={city}
                onChange={(e) => setCity(e.target.value)}
                className="w-full px-3 py-2 border border-stone-200 bg-white rounded-lg focus:outline-none focus:ring-1 focus:ring-brand-green-600 text-sm"
                placeholder="Manila"
                required
              />
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div>
              <label className="block text-xs font-bold uppercase text-stone-700 mb-1" htmlFor="admin-latitude">
                Latitude *
              </label>
              <input
                id="admin-latitude"
                type="number"
                step="any"
                value={lat}
                onChange={(e) => setLat(e.target.value === '' ? '' : Number(e.target.value))}
                className="w-full px-3 py-2 border border-stone-200 bg-white rounded-lg focus:outline-none focus:ring-1 focus:ring-brand-green-600 text-sm"
                placeholder="14.5995"
                required
              />
            </div>
            <div>
              <label className="block text-xs font-bold uppercase text-stone-700 mb-1" htmlFor="admin-longitude">
                Longitude *
              </label>
              <input
                id="admin-longitude"
                type="number"
                step="any"
                value={lng}
                onChange={(e) => setLng(e.target.value === '' ? '' : Number(e.target.value))}
                className="w-full px-3 py-2 border border-stone-200 bg-white rounded-lg focus:outline-none focus:ring-1 focus:ring-brand-green-600 text-sm"
                placeholder="120.9842"
                required
              />
            </div>
            <div>
              <label className="block text-xs font-bold uppercase text-stone-700 mb-1" htmlFor="admin-region">
                Region *
              </label>
              <select
                id="admin-region"
                value={region}
                onChange={(e) => setRegion(e.target.value as any)}
                className="w-full px-3 py-2 border border-stone-200 bg-white rounded-lg focus:outline-none focus:ring-1 focus:ring-brand-green-600 text-sm"
              >
                <option value="Luzon">Luzon</option>
                <option value="Visayas">Visayas</option>
                <option value="Mindanao">Mindanao</option>
              </select>
            </div>
          </div>

          <div>
            <label className="block text-xs font-bold uppercase text-stone-700 mb-1" htmlFor="admin-address">
              Complete Street Address *
            </label>
            <input
              id="admin-address"
              type="text"
              value={address}
              onChange={(e) => setAddress(e.target.value)}
              className="w-full px-3 py-2 border border-stone-200 bg-white rounded-lg focus:outline-none focus:ring-1 focus:ring-brand-green-600 text-sm"
              placeholder="G/F Heritage Hall, Robinsons Place Manila, Ermita, Manila"
              required
            />
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-bold uppercase text-stone-700 mb-1" htmlFor="admin-phone">
                Contact Phone *
              </label>
              <input
                id="admin-phone"
                type="text"
                value={phone}
                onChange={(e) => setPhone(e.target.value)}
                className="w-full px-3 py-2 border border-stone-200 bg-white rounded-lg focus:outline-none focus:ring-1 focus:ring-brand-green-600 text-sm"
                placeholder="+63 2 8244 5678"
                required
              />
            </div>
            <div>
              <label className="block text-xs font-bold uppercase text-stone-700 mb-1" htmlFor="admin-hours">
                Store Hours
              </label>
              <input
                id="admin-hours"
                type="text"
                value={hours}
                onChange={(e) => setHours(e.target.value)}
                className="w-full px-3 py-2 border border-stone-200 bg-white rounded-lg focus:outline-none focus:ring-1 focus:ring-brand-green-600 text-sm"
                placeholder="10:00 AM - 9:00 PM"
              />
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-bold uppercase text-stone-700 mb-1" htmlFor="admin-image-url">
                Store Thumbnail Image URL (Optional)
              </label>
              <input
                id="admin-image-url"
                type="text"
                value={image}
                onChange={(e) => setImage(e.target.value)}
                className="w-full px-3 py-2 border border-stone-200 bg-white rounded-lg focus:outline-none focus:ring-1 focus:ring-brand-green-600 text-sm"
                placeholder="https://picsum.photos/seed/... "
              />
            </div>
            <div>
              <label className="block text-xs font-bold uppercase text-stone-700 mb-1" htmlFor="admin-gmaps-link">
                Google Maps Link (Optional)
              </label>
              <input
                id="admin-gmaps-link"
                type="text"
                value={googleMapsLink}
                onChange={(e) => setGoogleMapsLink(e.target.value)}
                className="w-full px-3 py-2 border border-stone-200 bg-white rounded-lg focus:outline-none focus:ring-1 focus:ring-brand-green-600 text-sm"
                placeholder="https://maps.google.com/?q=..."
              />
            </div>
          </div>

          <div>
            <label className="block text-xs font-bold uppercase text-stone-700 mb-1" htmlFor="admin-tags-csv">
              Tags/Highlights (comma-separated list)
            </label>
            <input
              id="admin-tags-csv"
              type="text"
              value={tagsText}
              onChange={(e) => setTagsText(e.target.value)}
              className="w-full px-3 py-2 border border-stone-200 bg-white rounded-lg focus:outline-none focus:ring-1 focus:ring-brand-green-600 text-sm"
              placeholder="Apothecary Hub, Herbal Extracts Bar, Tea Sampling"
            />
          </div>

          <div className="flex items-center space-x-3 bg-white p-3 rounded-xl border border-stone-200">
            <input
              id="admin-featured"
              type="checkbox"
              checked={featured}
              onChange={(e) => setFeatured(e.target.checked)}
              className="w-4 h-4 text-brand-green-600 border-stone-300 rounded focus:ring-brand-green-500 cursor-pointer"
            />
            <label htmlFor="admin-featured" className="text-xs font-semibold text-stone-700 cursor-pointer select-none flex items-center space-x-1">
              <Star className="w-3.5 h-3.5 text-brand-gold-500 fill-brand-gold-500" />
              <span>Highlight as Featured Flagship Store</span>
            </label>
          </div>

          <div className="flex items-center justify-end space-x-3 pt-2">
            <button
              type="button"
              onClick={() => { setIsAdding(false); setEditingStoreId(null); }}
              className="px-4 py-2 border border-stone-200 text-sm text-stone-600 hover:text-stone-900 rounded-lg transition-colors cursor-pointer"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="flex items-center space-x-1.5 bg-brand-green-700 hover:bg-brand-green-800 text-white font-semibold text-sm px-5 py-2 rounded-lg transition-all cursor-pointer shadow-sm"
            >
              <Save className="w-4 h-4" />
              <span>Save Branch Detail</span>
            </button>
          </div>
        </form>
      ) : (
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-stone-500 uppercase tracking-widest">
              Available Store Databases ({stores.length})
            </span>
            <button
              onClick={startAdd}
              className="flex items-center space-x-1.5 bg-brand-green-700 hover:bg-brand-green-800 text-white font-semibold text-xs px-3 py-2 rounded-lg transition-all cursor-pointer shadow-sm"
            >
              <PlusCircle className="w-3.5 h-3.5" />
              <span>Create New Store</span>
            </button>
          </div>

          <div className="max-h-72 overflow-y-auto border border-stone-200 rounded-xl bg-white divide-y divide-stone-100">
            {stores.map((store) => (
              <div key={store.id} className="p-3.5 flex items-center justify-between hover:bg-stone-50 transition-colors">
                <div className="pr-4">
                  <div className="flex items-center space-x-1.5">
                    <h5 className="font-heading font-medium text-sm text-stone-800">{store.storeName}</h5>
                    {store.featured && (
                      <span className="bg-brand-gold-500/10 text-brand-gold-600 text-[9px] px-1.5 py-0.5 rounded-full font-bold flex items-center space-x-0.5 border border-brand-gold-500/20">
                        <Star className="w-2.5 h-2.5 fill-brand-gold-500" />
                        <span>Featured</span>
                      </span>
                    )}
                  </div>
                  <p className="text-xs text-stone-500 truncate max-w-xs md:max-w-md">{store.address}</p>
                  <p className="text-[10px] font-mono text-stone-400 mt-0.5">
                    ({store.region}) • {store.lat.toFixed(4)}, {store.lng.toFixed(4)}
                  </p>
                </div>

                <div className="flex items-center space-x-1.5 flex-shrink-0">
                  <button
                    onClick={() => startEdit(store)}
                    className="p-1.5 text-stone-500 hover:text-brand-green-600 hover:bg-stone-100 rounded-lg transition-colors border border-stone-100"
                    title="Edit Store"
                  >
                    <Edit className="w-3.5 h-3.5" />
                  </button>
                  <button
                    onClick={() => {
                      if (confirm(`Are you sure you want to delete ${store.storeName}?`)) {
                        onDeleteStore(store.id);
                      }
                    }}
                    className="p-1.5 text-stone-400 hover:text-rose-600 hover:bg-rose-50 rounded-lg transition-colors border border-stone-100"
                    title="Delete Store"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            ))}

            {stores.length === 0 && (
              <div className="p-8 text-center text-stone-500 font-sans text-xs">
                No stores registered yet. Click "Create New Store" above to populate one!
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
}
