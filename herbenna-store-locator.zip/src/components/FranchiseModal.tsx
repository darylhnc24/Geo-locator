/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { X, CheckCircle, Landmark, ShieldCheck, Mail, Send, Sparkles } from 'lucide-react';

interface FranchiseModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export default function FranchiseModal({ isOpen, onClose }: FranchiseModalProps) {
  const [formSubmitted, setFormSubmitted] = useState(false);
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [phone, setPhone] = useState('');
  const [location, setLocation] = useState('');
  const [capital, setCapital] = useState('1M-3M PHP');
  const [message, setMessage] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name || !email || !phone) return;
    setFormSubmitted(true);
  };

  const resetForm = () => {
    setFormSubmitted(false);
    setName('');
    setEmail('');
    setPhone('');
    setLocation('');
    setCapital('1M-3M PHP');
    setMessage('');
    onClose();
  };

  return (
    <AnimatePresence>
      {isOpen && (
        <div className="fixed inset-0 z-100 flex items-center justify-center p-4">
          {/* Backdrop */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={onClose}
            className="absolute inset-0 bg-stone-900/60 backdrop-blur-sm"
          />

          {/* Modal Container */}
          <motion.div
            initial={{ opacity: 0, scale: 0.95, y: 15 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.95, y: 15 }}
            className="relative w-full max-w-xl bg-white rounded-2xl shadow-2xl border border-stone-200 overflow-hidden z-10"
          >
            {/* Elegant Header Panel */}
            <div className="relative bg-gradient-to-r from-brand-green-700 to-brand-green-800 p-6 text-white">
              <button
                onClick={onClose}
                className="absolute top-4 right-4 p-1.5 rounded-full bg-white/10 text-white hover:bg-white/25 transition-colors"
                aria-label="Close modal"
              >
                <X className="w-5 h-5" />
              </button>
              <div className="flex items-center space-x-3 mb-2">
                <div className="w-10 h-10 rounded-lg bg-white/20 flex items-center justify-center text-brand-gold-500">
                  <Landmark className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="font-heading font-semibold text-lg text-white">Franchise Program</h3>
                  <p className="text-xs text-brand-green-100 uppercase tracking-widest font-semibold flex items-center gap-1">
                    <Sparkles className="w-3 h-3" /> Partner with Herbenna
                  </p>
                </div>
              </div>
            </div>

            {/* Form & Content */}
            <div className="p-6">
              {!formSubmitted ? (
                <form onSubmit={handleSubmit} className="space-y-4">
                  <p className="text-sm text-stone-600 leading-relaxed">
                    Join Philippines’ most trusted organic apothecary and wellness brand. Fill in this quick feasibility inquiry and our development division will get in touch.
                  </p>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-xs font-bold uppercase text-stone-700 mb-1.5" htmlFor="full-name">
                        Full Name <span className="text-red-500">*</span>
                      </label>
                      <input
                        id="full-name"
                        type="text"
                        required
                        value={name}
                        onChange={(e) => setName(e.target.value)}
                        className="w-full px-3 py-2.5 bg-stone-50 border border-stone-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-brand-green-600 focus:bg-white text-sm text-stone-800"
                        placeholder="E.g., Juan Dela Cruz"
                      />
                    </div>
                    <div>
                      <label className="block text-xs font-bold uppercase text-stone-700 mb-1.5" htmlFor="contact-phone">
                        Contact Number <span className="text-red-500">*</span>
                      </label>
                      <input
                        id="contact-phone"
                        type="tel"
                        required
                        value={phone}
                        onChange={(e) => setPhone(e.target.value)}
                        className="w-full px-3 py-2.5 bg-stone-50 border border-stone-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-brand-green-600 focus:bg-white text-sm text-stone-800"
                        placeholder="E.g., +63 912 345 6789"
                      />
                    </div>
                  </div>

                  <div>
                    <label className="block text-xs font-bold uppercase text-stone-700 mb-1.5" htmlFor="email-address">
                      Email Address <span className="text-red-500">*</span>
                    </label>
                    <input
                      id="email-address"
                      type="email"
                      required
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      className="w-full px-3 py-2.5 bg-stone-50 border border-stone-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-brand-green-600 focus:bg-white text-sm text-stone-800"
                      placeholder="E.g., juan@example.com"
                    />
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-xs font-bold uppercase text-stone-700 mb-1.5" htmlFor="target-location">
                        Target Territory / Location
                      </label>
                      <input
                        id="target-location"
                        type="text"
                        value={location}
                        onChange={(e) => setLocation(e.target.value)}
                        className="w-full px-3 py-2.5 bg-stone-50 border border-stone-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-brand-green-600 focus:bg-white text-sm text-stone-800"
                        placeholder="E.g., Iloilo City, Taguig, etc."
                      />
                    </div>
                    <div>
                      <label className="block text-xs font-bold uppercase text-stone-700 mb-1.5" htmlFor="investment-capital">
                        Available Capital Range
                      </label>
                      <select
                        id="investment-capital"
                        value={capital}
                        onChange={(e) => setCapital(e.target.value)}
                        className="w-full px-3 py-2.5 bg-stone-50 border border-stone-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-brand-green-600 focus:bg-white text-sm text-stone-800"
                      >
                        <option>300k - 500k PHP</option>
                        <option>500k - 1M PHP</option>
                        <option>1M - 3M PHP</option>
                        <option>3M - 5M PHP</option>
                        <option>Over 5M PHP</option>
                      </select>
                    </div>
                  </div>

                  <div>
                    <label className="block text-xs font-bold uppercase text-stone-700 mb-1.5" htmlFor="cover-message">
                      Why partner with Herbenna? (Optional)
                    </label>
                    <textarea
                      id="cover-message"
                      rows={3}
                      value={message}
                      onChange={(e) => setMessage(e.target.value)}
                      className="w-full px-3 py-2.5 bg-stone-50 border border-stone-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-brand-green-600 focus:bg-white text-sm text-stone-800 resize-none"
                      placeholder="Share your experience or interest in wellness franchise..."
                    />
                  </div>

                  {/* Trust Footer inside form */}
                  <div className="flex items-center space-x-2 bg-stone-50 p-3 rounded-lg border border-stone-100 text-[11px] text-stone-500">
                    <ShieldCheck className="w-4 h-4 text-brand-green-600 flex-shrink-0" />
                    <span>Your data is strictly confidential, protected under the PH Data Privacy Act of 2012.</span>
                  </div>

                  {/* Submission CTA */}
                  <div className="flex items-center justify-end space-x-3 pt-2">
                    <button
                      type="button"
                      onClick={onClose}
                      className="px-4 py-2 text-sm text-stone-600 hover:text-stone-900 hover:bg-stone-100 rounded-lg transition-colors duration-200"
                    >
                      Cancel
                    </button>
                    <button
                      type="submit"
                      className="flex items-center space-x-2 bg-brand-green-700 hover:bg-brand-green-800 text-white font-semibold text-sm px-5 py-2.5 rounded-lg shadow-md hover:shadow-lg transition-all duration-200 cursor-pointer"
                    >
                      <Send className="w-4 h-4" />
                      <span>Submit Application</span>
                    </button>
                  </div>
                </form>
              ) : (
                <motion.div
                  initial={{ opacity: 0, scale: 0.95 }}
                  animate={{ opacity: 1, scale: 1 }}
                  className="text-center py-8 space-y-4"
                >
                  <div className="mx-auto w-16 h-16 rounded-full bg-brand-green-50 flex items-center justify-center text-brand-green-600 border border-brand-green-200 shadow-inner">
                    <CheckCircle className="w-10 h-10" />
                  </div>
                  <div className="max-w-md mx-auto space-y-2">
                    <h4 className="font-heading font-semibold text-xl text-stone-900">Application Received, {name}!</h4>
                    <p className="text-sm text-stone-600 leading-relaxed">
                      Thank you for your interest in Herbenna's franchise program. Your proposal reference number is <strong className="text-brand-green-700 font-semibold font-mono">HR-2026-{Math.floor(Math.random() * 9000) + 1000}</strong>.
                    </p>
                    <p className="text-xs text-stone-500">
                      Our commercial onboarding officer will evaluate your application for <span className="font-semibold text-stone-700">{location || 'your preferred location'}</span> and email you at <span className="underline">{email}</span> within 24–48 hours.
                    </p>
                  </div>
                  <div className="pt-6">
                    <button
                      onClick={resetForm}
                      className="bg-stone-900 text-stone-100 hover:bg-stone-800 text-sm font-semibold px-6 py-2.5 rounded-lg transition-colors duration-200 cursor-pointer"
                    >
                      Return to Store Locator
                    </button>
                  </div>
                </motion.div>
              )}
            </div>
          </motion.div>
        </div>
      )}
    </AnimatePresence>
  );
}
