/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useEffect, useState } from 'react';
import { motion } from 'motion/react';
import { Leaf, Award, Heart, ShieldCheck, UserCheck, Star, Sparkles, Sprout } from 'lucide-react';

interface CounterProps {
  end: number;
  suffix?: string;
  label: string;
}

function AnimatedCounter({ end, suffix = '', label }: CounterProps) {
  const [count, setCount] = useState(0);

  useEffect(() => {
    let startTime: number | null = null;
    const duration = 2000; // 2 seconds

    const animate = (timestamp: number) => {
      if (!startTime) startTime = timestamp;
      const progress = Math.min((timestamp - startTime) / duration, 1);
      setCount(Math.floor(progress * end));

      if (progress < 1) {
        requestAnimationFrame(animate);
      }
    };

    requestAnimationFrame(animate);
  }, [end]);

  return (
    <div className="text-center p-6 bg-white/70 backdrop-blur-sm shadow-sm rounded-2xl border border-stone-200/50">
      <div className="text-3xl sm:text-4xl font-bold font-heading text-brand-green-700 tracking-tight flex items-baseline justify-center">
        <span>{count}</span>
        <span className="text-xl sm:text-2xl ml-0.5 text-brand-gold-500 font-semibold">{suffix}</span>
      </div>
      <p className="text-xs sm:text-sm text-stone-600 font-medium mt-1.5">{label}</p>
    </div>
  );
}

export default function PromoSection() {
  const featuredProducts = [
    {
      name: "Moringa Defense Serum",
      description: "Advanced daily hydration extracted from selected local Malunggay leaves. Rich in vitamin E, amino acids, and antioxidant properties.",
      tags: ["Anti-Aging", "Hydration", "100% Pure"],
      image: "https://picsum.photos/seed/moringa-serum/400/300"
    },
    {
      name: "Golden Turmeric Elixir",
      description: "Potent anti-inflammatory herbal concentrate infused with Mindanao Luyang Dilaw, raw wild honey, and cold-pressed citrus extracts.",
      tags: ["Immunity", "Digestion", "Wild Honey"],
      image: "https://picsum.photos/seed/turmeric-elixir/400/300"
    },
    {
      name: "Pure Coconut Leaf Salve",
      description: "Traditional cooling remedy utilizing Virgin Coconut Oil and organic leaf extract blends. Instant relief for muscle fatigue and dry skin.",
      tags: ["Muscle Relief", "Soothing", "Zero Waste"],
      image: "https://picsum.photos/seed/coconut-salve/400/300"
    }
  ];

  const testimonials = [
    {
      name: "Amara S. Dela Rosa",
      role: "Certified Yoga Instructor, Cebu City",
      quote: "Herbenna Cebu became my sanctuary. Buying fresh herbal extracts and essential oils local from Philippine farmers gives me absolute piece of mind. The consultation bar is fantastic!",
      stars: 5
    },
    {
      name: "Dr. Matthew Pascual",
      role: "Holistic Health Therapist, Quezon City",
      quote: "I highly recommend Herbenna's Moringa Defense Serum to my patients. The extraction standard is scientifically pure and pristine, easily putting international brands to shame.",
      stars: 5
    }
  ];

  return (
    <section id="promo" className="py-20 bg-gradient-to-b from-[#fcfaf2] to-white relative overflow-hidden">
      {/* Decorative leafy backdrop circles */}
      <div className="absolute top-1/4 -left-32 w-96 h-96 bg-brand-green-50 rounded-full blur-3xl opacity-60 pointer-events-none" />
      <div className="absolute bottom-10 -right-32 w-80 h-80 bg-amber-50 rounded-full blur-3xl opacity-60 pointer-events-none" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Core Stats Bar */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 sm:gap-6 mb-20">
          <AnimatedCounter end={12} suffix="+" label="Premium Outlets" />
          <AnimatedCounter end={100} suffix="%" label="Organic Certified" />
          <AnimatedCounter end={25} suffix="K+" label="Loyal Patrons" />
          <AnimatedCounter end={150} suffix="+" label="Local Farms Supported" />
        </div>

        {/* Section Title */}
        <div className="text-center max-w-3xl mx-auto mb-16 space-y-4">
          <div className="inline-flex items-center space-x-1.5 px-3 py-1 bg-brand-green-50 border border-brand-green-200 rounded-full">
            <Sprout className="w-4 h-4 text-brand-green-600" />
            <span className="text-xs font-semibold text-brand-green-700 uppercase tracking-widest leading-none">
              Apothecary Specialties
            </span>
          </div>
          <h2 className="font-heading font-semibold text-3xl sm:text-4xl text-stone-900 tracking-tight leading-tight">
            Crafted with Wisdom, Proven by Nature
          </h2>
          <p className="text-sm sm:text-base text-stone-600 leading-relaxed font-sans">
            Herbenna transforms precious Philippine herbs into accessible lifestyle products. Explore our curated flagship items, formulated to bring absolute serenity and physical defense to your everyday household.
          </p>
        </div>

        {/* Products Grid */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-24">
          {featuredProducts.map((product, i) => (
            <div 
              key={i} 
              className="bg-white rounded-2xl border border-stone-200 hover:border-brand-green-200 overflow-hidden shadow-sm hover:shadow-xl transition-all duration-300 flex flex-col group"
            >
              <div className="h-52 bg-stone-100 overflow-hidden relative">
                <img 
                  src={product.image} 
                  alt={product.name}
                  referrerPolicy="no-referrer"
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                />
                <div className="absolute top-4 left-4 flex gap-1.5">
                  {product.tags.slice(0, 2).map((t, idx) => (
                    <span key={idx} className="bg-white/95 backdrop-blur-sm text-stone-800 text-[10px] font-bold px-2.5 py-1 rounded-full border border-stone-100">
                      {t}
                    </span>
                  ))}
                </div>
              </div>
              <div className="p-6 flex-1 flex flex-col justify-between">
                <div className="space-y-2">
                  <h3 className="font-heading font-semibold text-stone-900 group-hover:text-brand-green-700 transition-colors">
                    {product.name}
                  </h3>
                  <p className="text-stone-600 text-xs sm:text-sm leading-relaxed">
                    {product.description}
                  </p>
                </div>
                <div className="pt-6 border-t border-stone-100 flex items-center justify-between text-xs font-semibold">
                  <span className="text-stone-400">Available Nationwide</span>
                  <a href="#locator" className="text-brand-green-700 hover:text-brand-green-800 hover:underline inline-flex items-center space-x-0.5">
                    <span>Locate Store</span>
                    <span>→</span>
                  </a>
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* Testimonials */}
        <div className="bg-stone-50 border border-stone-200 rounded-3xl p-8 sm:p-12 relative overflow-hidden flex flex-col md:flex-row gap-12 items-center">
          <div className="md:w-1/3 space-y-4">
            <div className="w-12 h-12 rounded-2xl bg-brand-green-100 text-brand-green-700 flex items-center justify-center">
              <UserCheck className="w-6 h-6" />
            </div>
            <h3 className="font-heading font-semibold text-2xl text-stone-900 leading-tight">
              Loved by Practitioners & Purists
            </h3>
            <p className="text-xs text-stone-500 leading-relaxed">
              Discover why families and certified holistic counselors across Metro Manila, Cebu, and Mindanao choose Herbenna.
            </p>
          </div>

          <div className="md:w-2/3 grid grid-cols-1 sm:grid-cols-2 gap-6 w-full">
            {testimonials.map((t, i) => (
              <div key={i} className="bg-white p-6 rounded-2xl border border-stone-200 shadow-sm space-y-4 flex flex-col justify-between">
                <div className="space-y-3">
                  <div className="flex gap-0.5 text-brand-gold-500">
                    {[...Array(t.stars)].map((_, idx) => (
                      <Star key={idx} className="w-4 h-4 fill-brand-gold-500" />
                    ))}
                  </div>
                  <p className="text-stone-600 text-xs sm:text-sm italic leading-relaxed">
                    “{t.quote}”
                  </p>
                </div>
                <div>
                  <h4 className="font-heading font-semibold text-xs sm:text-sm text-stone-900">{t.name}</h4>
                  <p className="text-[10px] text-brand-green-600 uppercase tracking-wider font-semibold mt-0.5">{t.role}</p>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Quality Assurances */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-6 pt-16 border-t border-stone-200 mt-20 text-center">
          <div className="flex flex-col items-center space-y-2">
            <div className="w-10 h-10 rounded-full bg-brand-green-50 flex items-center justify-center text-brand-green-700 border border-brand-green-100">
              <Leaf className="w-5 h-5 animate-pulse" />
            </div>
            <h4 className="font-heading font-semibold text-stone-900 text-sm">Responsibly Sourced</h4>
            <p className="text-xs text-stone-500 max-w-xs leading-relaxed">Sourced directly from indigenous cooperatives and high-integrity smallholder farms.</p>
          </div>
          <div className="flex flex-col items-center space-y-2">
            <div className="w-10 h-10 rounded-full bg-brand-green-50 flex items-center justify-center text-brand-green-700 border border-brand-green-100">
              <ShieldCheck className="w-5 h-5" />
            </div>
            <h4 className="font-heading font-semibold text-stone-900 text-sm">Laboratory Guarded</h4>
            <p className="text-xs text-stone-500 max-w-xs leading-relaxed">Every batch submits to full chromatographic analysis to guarantee maximum bio-active potency.</p>
          </div>
          <div className="flex flex-col items-center space-y-2">
            <div className="w-10 h-10 rounded-full bg-brand-green-50 flex items-center justify-center text-brand-green-700 border border-brand-green-100">
              <Award className="w-5 h-5 hover:rotate-12 transition-transform" />
            </div>
            <h4 className="font-heading font-semibold text-stone-900 text-sm">Award Winner</h4>
            <p className="text-xs text-stone-500 max-w-xs leading-relaxed">Recognized nationally for pioneering agricultural sustainability and premium product standards.</p>
          </div>
        </div>

      </div>
    </section>
  );
}
