/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { MapPin, Settings, ShieldAlert, Sparkles, LogOut, Check } from 'lucide-react';
import HerbennaLogo from './Logo';

interface HeaderProps {
  onAdminToggle: () => void;
  isAdminOpen: boolean;
  mapTheme: 'light' | 'warm' | 'dark';
  setMapTheme: (theme: 'light' | 'warm' | 'dark') => void;
  isDeveloperMode: boolean;
  onExitDeveloper: () => void;
  onEnterDeveloper: () => void;
}

export default function Header({ 
  onAdminToggle, 
  isAdminOpen, 
  mapTheme, 
  setMapTheme,
  isDeveloperMode,
  onExitDeveloper,
  onEnterDeveloper
}: HeaderProps) {
  return (
    <header className="sticky top-0 z-50 bg-white/95 backdrop-blur-md border-b border-stone-200 shadow-xs">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-20 flex items-center justify-between">
        
        {/* Brand Logo - Now with Herbenna Logo and interactive map switcher indicator */}
        <div 
          className="flex items-center space-x-3 cursor-pointer group" 
          onClick={() => window.scrollTo({ top: 0, behavior: 'smooth' })}
        >
          <HerbennaLogo className="h-10 sm:h-12 w-auto" />
          
          {isDeveloperMode ? (
            <span className="hidden sm:inline-flex items-center gap-1.5 bg-emerald-100 text-emerald-800 text-[10px] sm:text-xs font-bold px-2 py-0.5 rounded-full uppercase tracking-wider animate-pulse">
              <Check className="w-3 h-3" /> Dev View
            </span>
          ) : null}
        </div>

        {/* Desk Nav */}
        <nav className="hidden md:flex items-center space-x-8 text-sm font-medium text-stone-600 font-sans">
          <a 
            onClick={() => window.scrollTo({ top: 0, behavior: 'smooth' })} 
            className="hover:text-brand-green-600 transition-colors duration-200 flex items-center space-x-1.5 cursor-pointer"
          >
            <MapPin className="w-4 h-4 text-brand-green-600" />
            <span className="font-bold text-stone-800">Interactive Map</span>
          </a>
        </nav>

        {/* Actions & Themes */}
        <div className="flex items-center space-x-3">
          {/* Map theme togglers - Clean and simplified for all users */}
          <div className="hidden sm:flex items-center bg-stone-100 rounded-lg p-1 border border-stone-200 text-xs">
            <button
              onClick={() => setMapTheme('light')}
              className={`px-2.5 py-1 rounded-md font-medium transition-all duration-200 ${
                mapTheme === 'light' ? 'bg-white text-stone-900 shadow-sm' : 'text-stone-500 hover:text-stone-900'
              }`}
            >
              Light Map
            </button>
            <button
              onClick={() => setMapTheme('warm')}
              className={`px-2.5 py-1 rounded-md font-medium transition-all duration-200 ${
                mapTheme === 'warm' ? 'bg-amber-100 text-amber-900 shadow-sm' : 'text-stone-500 hover:text-stone-900'
              }`}
            >
              Amber Map
            </button>
            <button
              onClick={() => setMapTheme('dark')}
              className={`px-2.5 py-1 rounded-md font-medium transition-all duration-200 ${
                mapTheme === 'dark' ? 'bg-stone-900 text-stone-100 shadow-sm' : 'text-stone-500 hover:text-stone-900'
              }`}
            >
              Dim Map
            </button>
          </div>

          {/* Quick exit Developer session if logged in */}
          {isDeveloperMode && (
            <button
              onClick={onExitDeveloper}
              title="Exit Developer View"
              className="flex items-center justify-center p-2 rounded-lg bg-stone-50 hover:bg-red-50 hover:text-red-600 border border-stone-200 hover:border-red-200 transition-colors duration-150 cursor-pointer"
            >
              <LogOut className="w-4 h-4" />
              <span className="hidden lg:inline text-xs font-bold ml-1.5">Exit Dev</span>
            </button>
          )}
        </div>
      </div>
    </header>
  );
}
