/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';

export default function HerbennaLogo({ className = 'h-11 w-auto' }: { className?: string }) {
  return (
    <div className={`flex items-center ${className}`}>
      <img
        src="https://assets.cdn.filesafe.space/n2vpVM60wn80Mx3ts7FY/media/6a1e4af0282a51721aeef432.png"
        alt="Herbenna Logo"
        referrerPolicy="no-referrer"
        className="h-full w-auto object-contain max-h-full"
      />
    </div>
  );
}
