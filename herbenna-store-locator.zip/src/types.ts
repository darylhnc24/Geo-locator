/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export interface Store {
  id: string;
  storeName: string;
  lat: number;
  lng: number;
  address: string;
  phone: string;
  hours: string;
  image: string;
  googleMapsLink: string;
  region: 'Luzon' | 'Visayas' | 'Mindanao';
  city: string;
  tags?: string[];
  featured?: boolean;
}

export interface UserLocation {
  lat: number;
  lng: number;
}
