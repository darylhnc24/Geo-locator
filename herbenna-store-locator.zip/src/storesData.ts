/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { Store } from './types';

export const INITIAL_STORES: Store[] = [
  // 1. Imus Branch
  {
    id: 'store-1-imus',
    storeName: 'Imus Branch',
    lat: 14.412670,
    lng: 120.941654,
    address: '2/F Macneny Bldg., 85 Emilio Aguinaldo Hwy., Bayan Luma IV, Imus, Cavite 4103',
    phone: '9089617949 / 9128072590',
    hours: 'Mon to Sun, 8:00 AM to 5:00 PM',
    image: 'https://static-maps.yandex.ru/1.x/?lang=en_US&ll=120.941654,14.412670&z=15&l=map&size=450,300&pt=120.941654,14.412670,pm2rdm',
    googleMapsLink: 'https://maps.google.com/?q=14.412670,120.941654',
    region: 'Luzon',
    city: 'Imus',
    tags: ['Cavite Outlet', 'Authorized Outlet'],
    featured: false
  },

  // 2. Kawit Branch
  {
    id: 'store-2-kawit',
    storeName: 'Kawit Branch',
    lat: 14.441113,
    lng: 120.903201,
    address: 'Phoenix Gasoline Station, Antero Soriano Hwy corner Daang Hari Link, Tabon I, Kawit, Cavite 4104',
    phone: '9932848546 / 9128072590',
    hours: 'Mon to Sun, 8:00 AM to 5:00 PM',
    image: 'https://static-maps.yandex.ru/1.x/?lang=en_US&ll=120.903201,14.441113&z=15&l=map&size=450,300&pt=120.903201,14.441113,pm2rdm',
    googleMapsLink: 'https://maps.google.com/?q=14.441113,120.903201',
    region: 'Luzon',
    city: 'Kawit',
    tags: ['Kawit Outlet', 'Authorized Outlet'],
    featured: false
  },

  // 3. Tagaytay Branch
  {
    id: 'store-3-tagaytay',
    storeName: 'Tagaytay Branch',
    lat: 14.097220,
    lng: 120.932906,
    address: 'Unit 5 G/F JLC Bldg., Tagaytay-Nasugbu Hwy., Mendez Crossing West, Tagaytay, Cavite 4120',
    phone: '9128072590',
    hours: 'Mon to Sun, 8:00 AM to 5:00 PM',
    image: 'https://static-maps.yandex.ru/1.x/?lang=en_US&ll=120.932906,14.097220&z=15&l=map&size=450,300&pt=120.932906,14.097220,pm2rdm',
    googleMapsLink: 'https://maps.google.com/?q=14.097220,120.932906',
    region: 'Luzon',
    city: 'Tagaytay',
    tags: ['Tagaytay Hub', 'Primary Outlet', 'Featured'],
    featured: true
  },

  // 4. Las Piñas/Zapote Branch
  {
    id: 'store-4-laspinas',
    storeName: 'Las Piñas/Zapote Branch',
    lat: 14.465296,
    lng: 120.970548,
    address: '1A G-21 Zapote Arcade, Emilio Aguinaldo Hwy corner Alabang-Zapote Rd., Zapote, Las Piñas, Metro Manila 1742',
    phone: '9339271254 / 9128072590',
    hours: 'Mon to Sat, 8:00 AM to 5:00 PM',
    image: 'https://static-maps.yandex.ru/1.x/?lang=en_US&ll=120.970548,14.465296&z=15&l=map&size=450,300&pt=120.970548,14.465296,pm2rdm',
    googleMapsLink: 'https://maps.google.com/?q=14.465296,120.970548',
    region: 'Luzon',
    city: 'Las Piñas',
    tags: ['Las Piñas Outlet', 'Authorized Outlet'],
    featured: false
  },

  // 5. Hermosa Branch
  {
    id: 'store-5-hermosa',
    storeName: 'Hermosa Branch',
    lat: 14.843126,
    lng: 120.504261,
    address: 'New Hermosa Public Market, Bataan Provincial Hwy., Palihan, Hermosa, Bataan 2111',
    phone: '9778374035 / 9179495145',
    hours: 'Mon to Sat, 8:00 AM to 5:00 PM',
    image: 'https://static-maps.yandex.ru/1.x/?lang=en_US&ll=120.504261,14.843126&z=15&l=map&size=450,300&pt=120.504261,14.843126,pm2rdm',
    googleMapsLink: 'https://maps.google.com/?q=14.843126,120.504261',
    region: 'Luzon',
    city: 'Hermosa',
    tags: ['Bataan Market', 'Authorized Market Stall'],
    featured: false
  },

  // 6. Pilar Branch
  {
    id: 'store-6-pilar',
    storeName: 'Pilar Branch',
    lat: 14.654885,
    lng: 120.510367,
    address: 'Gov. J.J. Linao National Rd near Ala-Uli Flyover, Ala-Uli, Pilar, Bataan 2101',
    phone: '9778374035 / 9179495145',
    hours: 'Mon to Sat, 8:00 AM to 5:00 PM | Sun, 8:00 AM to 1:00 PM',
    image: 'https://static-maps.yandex.ru/1.x/?lang=en_US&ll=120.510367,14.654885&z=15&l=map&size=450,300&pt=120.510367,14.654885,pm2rdm',
    googleMapsLink: 'https://maps.google.com/?q=14.654885,120.510367',
    region: 'Luzon',
    city: 'Pilar',
    tags: ['Bataan Outlet', 'Authorized Outlet'],
    featured: false
  },

  // 7. Commonwealth Branch
  {
    id: 'store-7-commonwealth',
    storeName: 'Commonwealth Branch',
    lat: 14.685809,
    lng: 121.096347,
    address: 'Stall me5-4 Commonwealth Market, 9 Commonwealth Ave., Commonwealth, Quezon City, Metro Manila 1121',
    phone: '9778374035 / 9212185672',
    hours: 'Mon to Sun, 8:00 AM to 6:00 PM',
    image: 'https://static-maps.yandex.ru/1.x/?lang=en_US&ll=121.096347,14.685809&z=15&l=map&size=450,300&pt=121.096347,14.685809,pm2rdm',
    googleMapsLink: 'https://maps.google.com/?q=14.685809,121.096347',
    region: 'Luzon',
    city: 'Quezon City',
    tags: ['Market Stall', 'Authorized Outlet'],
    featured: false
  },

  // 8. Muñoz Congressional Branch
  {
    id: 'store-8-munoz',
    storeName: 'Muñoz Congressional Branch',
    lat: 14.658090,
    lng: 121.019553,
    address: 'Stall 9D G/F EDSA C Plaza, Congressional Ave corner EDSA, Ramon Magsaysay, Quezon City, Metro Manila 1106',
    phone: '9501501249 / 9778374035',
    hours: 'Mon to Sun, 8:00 AM to 6:00 PM',
    image: 'https://static-maps.yandex.ru/1.x/?lang=en_US&ll=121.019553,14.658090&z=15&l=map&size=450,300&pt=121.019553,14.658090,pm2rdm',
    googleMapsLink: 'https://maps.google.com/?q=14.658090,121.019553',
    region: 'Luzon',
    city: 'Quezon City',
    tags: ['EDSA Hub', 'Authorized Outlet'],
    featured: false
  },

  // 9. Olongapo Branch
  {
    id: 'store-9-olongapo',
    storeName: 'Olongapo Branch',
    lat: 14.840605,
    lng: 120.282105,
    address: 'Stall 33 Blk J, Olongapo City Public Market, Jose Abad Santos Ave., West Bajac-Bajac, Olongapo, Olongapo 2200',
    phone: '9778374035',
    hours: 'Mon to Sat, 8:00 AM to 5:00 PM',
    image: 'https://static-maps.yandex.ru/1.x/?lang=en_US&ll=120.282105,14.840605&z=15&l=map&size=450,300&pt=120.282105,14.840605,pm2rdm',
    googleMapsLink: 'https://maps.google.com/?q=14.840605,120.282105',
    region: 'Luzon',
    city: 'Olongapo',
    tags: ['Zambales Market', 'Authorized Outlet'],
    featured: false
  },

  // 10. Angeles Branch
  {
    id: 'store-10-angeles',
    storeName: 'Angeles Branch',
    lat: 15.131107,
    lng: 120.590303,
    address: 'Stall 1-02 G/F, San Nicholas Public Market, Miranda St corner Rizal St, San Nicolas, Angeles, Pampanga 2009',
    phone: '9778374035 / 9179495145',
    hours: 'Mon to Sat, 8:00 AM to 5:00 PM',
    image: 'https://static-maps.yandex.ru/1.x/?lang=en_US&ll=120.590303,15.131107&z=15&l=map&size=450,300&pt=120.590303,15.131107,pm2rdm',
    googleMapsLink: 'https://maps.google.com/?q=15.131107,120.590303',
    region: 'Luzon',
    city: 'Angeles',
    tags: ['Pampanga Market', 'Authorized Outlet'],
    featured: false
  },

  // 11. San Fernando Branch
  {
    id: 'store-11-sanfernando',
    storeName: 'San Fernando Branch',
    lat: 15.038919,
    lng: 120.674205,
    address: 'G/F GBR Business Center, MacArthur Hwy beside Dolores Intersection, Dolores, San Fernando, Pampanga 2000',
    phone: '9778374035 / 9179495145',
    hours: 'Mon to Sat, 8:00 AM to 5:00 PM',
    image: 'https://static-maps.yandex.ru/1.x/?lang=en_US&ll=120.674205,15.038919&z=15&l=map&size=450,300&pt=120.674205,15.038919,pm2rdm',
    googleMapsLink: 'https://maps.google.com/?q=15.038919,120.674205',
    region: 'Luzon',
    city: 'San Fernando',
    tags: ['Pampanga Hub', 'Authorized Outlet'],
    featured: false
  },

  // 12. Pangasinan Branch
  {
    id: 'store-12-pangasinan',
    storeName: 'Pangasinan Branch',
    lat: 15.893989,
    lng: 120.635334,
    address: 'Stall A4, Rosales Public Market, San Jose - Carmen Rd corner Cassanova St, Zone II (Pob.), Rosales, Pangasinan 2441',
    phone: '9778374035 / 9179495145',
    hours: 'Mon to Sat, 8:00 AM to 5:00 PM',
    image: 'https://static-maps.yandex.ru/1.x/?lang=en_US&ll=120.635334,15.893989&z=15&l=map&size=450,300&pt=120.635334,15.893989,pm2rdm',
    googleMapsLink: 'https://maps.google.com/?q=15.893989,120.635334',
    region: 'Luzon',
    city: 'Rosales',
    tags: ['Pangasinan Market', 'Authorized Outlet'],
    featured: false
  },

  // 13. Tarlac Branch
  {
    id: 'store-13-tarlac',
    storeName: 'Tarlac Branch',
    lat: 15.483892,
    lng: 120.594738,
    address: 'Blk 2 Zamora St, San Roque, Tarlac, Tarlac 2300',
    phone: '9778374035 / 9179495145',
    hours: 'Mon to Sat, 8:00 AM to 5:00 PM',
    image: 'https://static-maps.yandex.ru/1.x/?lang=en_US&ll=120.594738,15.483892&z=15&l=map&size=450,300&pt=120.594738,15.483892,pm2rdm',
    googleMapsLink: 'https://maps.google.com/?q=15.483892,120.594738',
    region: 'Luzon',
    city: 'Tarlac',
    tags: ['Tarlac Hub', 'Authorized Outlet'],
    featured: false
  },

  // 14. Cubao Branch
  {
    id: 'store-14-cubao',
    storeName: 'Cubao Branch',
    lat: 14.616303,
    lng: 121.053536,
    address: 'Unit G10-B G/F Regalia Park Tower, 150 P. Tuazon Blvd, Socorro, Cubao, Quezon City, Metro Manila 1109',
    phone: '9310119843 / 9108048285',
    hours: 'Mon to Sat, 8:00 AM to 5:00 PM',
    image: 'https://static-maps.yandex.ru/1.x/?lang=en_US&ll=121.053536,14.616303&z=15&l=map&size=450,300&pt=121.053536,14.616303,pm2rdm',
    googleMapsLink: 'https://maps.google.com/?q=14.616303,121.053536',
    region: 'Luzon',
    city: 'Quezon City',
    tags: ['Transit Hub', 'Primary Outlet', 'Featured'],
    featured: true
  },

  // 15. Marikina Branch
  {
    id: 'store-15-marikina',
    storeName: 'Marikina Branch',
    lat: 14.650521,
    lng: 121.103845,
    address: 'Stall No. 8 Concepcion Market Annex, 6 E. Santos St, Concepcion Uno, Marikina, Metro Manila 1807',
    phone: '9303757184 / 9108048285',
    hours: 'Mon to Sat, 8:00 AM to 5:00 PM',
    image: 'https://static-maps.yandex.ru/1.x/?lang=en_US&ll=121.103845,14.650521&z=15&l=map&size=450,300&pt=121.103845,14.650521,pm2rdm',
    googleMapsLink: 'https://maps.google.com/?q=14.650521,121.103845',
    region: 'Luzon',
    city: 'Marikina',
    tags: ['Marikina Market', 'Authorized Outlet'],
    featured: false
  },

  // 16. Pasig Branch
  {
    id: 'store-16-pasig',
    storeName: 'Pasig Branch',
    lat: 14.590439,
    lng: 121.085145,
    address: '2/F Rosario Bldg, 38 Ortigas Ave, Rosario, Pasig, Metro Manila 1609',
    phone: '9308961684 / 9108048285',
    hours: 'Mon to Sat, 8:00 AM to 5:00 PM',
    image: 'https://static-maps.yandex.ru/1.x/?lang=en_US&ll=121.085145,14.590439&z=15&l=map&size=450,300&pt=121.085145,14.590439,pm2rdm',
    googleMapsLink: 'https://maps.google.com/?q=14.590439,121.085145',
    region: 'Luzon',
    city: 'Pasig',
    tags: ['Rosario Outlet', 'Authorized Outlet'],
    featured: false
  },

  // 17. Angono Branch
  {
    id: 'store-17-angono',
    storeName: 'Angono Branch',
    lat: 14.524080,
    lng: 121.152434,
    address: '2/F Leopards Square, 212 Doña Aurora St, Poblacion Itaas, Angono, Rizal 1930',
    phone: '9265103064 / 9108048285',
    hours: 'Mon to Sat, 8:00 AM to 5:00 PM',
    image: 'https://static-maps.yandex.ru/1.x/?lang=en_US&ll=121.152434,14.524080&z=15&l=map&size=450,300&pt=121.152434,14.524080,pm2rdm',
    googleMapsLink: 'https://maps.google.com/?q=14.524080,121.152434',
    region: 'Luzon',
    city: 'Angono',
    tags: ['Rizal Branch', 'Authorized Outlet'],
    featured: false
  },

  // 18. Antipolo Branch
  {
    id: 'store-18-antipolo',
    storeName: 'Antipolo Branch',
    lat: 14.587378,
    lng: 121.175403,
    address: 'Puregold Antipolo, General Luna St corner P. Oliveros St, San Roque (Pob.), Antipolo, Rizal 1870',
    phone: '9292360093 / 9363941020',
    hours: 'Mon to Sat, 8:00 AM to 5:00 PM',
    image: 'https://static-maps.yandex.ru/1.x/?lang=en_US&ll=121.175403,14.587378&z=15&l=map&size=450,300&pt=121.175403,14.587378,pm2rdm',
    googleMapsLink: 'https://maps.google.com/?q=14.587378,121.175403',
    region: 'Luzon',
    city: 'Antipolo',
    tags: ['Antipolo Plaza', 'Authorized Outlet'],
    featured: false
  },

  // 19. Binangonan Branch
  {
    id: 'store-19-binangonan',
    storeName: 'Binangonan Branch',
    lat: 14.469949,
    lng: 121.185203,
    address: '2/F DFR Apartment, Binangonan National Rd, Calumpang, Binangonan, Rizal 1940',
    phone: '9518563926 / 9108048285',
    hours: 'Mon to Sat, 8:00 AM to 5:00 PM',
    image: 'https://static-maps.yandex.ru/1.x/?lang=en_US&ll=121.185203,14.469949&z=15&l=map&size=450,300&pt=121.185203,14.469949,pm2rdm',
    googleMapsLink: 'https://maps.google.com/?q=14.469949,121.185203',
    region: 'Luzon',
    city: 'Binangonan',
    tags: ['Rizal Outlet', 'Authorized Outlet'],
    featured: false
  },

  // 20. Rodriguez Branch
  {
    id: 'store-20-rodriguez',
    storeName: 'Rodriguez Branch',
    lat: 14.729083,
    lng: 121.152400,
    address: '2/F RA Nocon Bldg, 240 Rodriguez Hwy, Manggahan, Rodriguez, Rizal 1860',
    phone: '9120411442 / 9108048285',
    hours: 'Mon to Sat, 8:00 AM to 5:00 PM',
    image: 'https://static-maps.yandex.ru/1.x/?lang=en_US&ll=121.152400,14.729083&z=15&l=map&size=450,300&pt=121.152400,14.729083,pm2rdm',
    googleMapsLink: 'https://maps.google.com/?q=14.729083,121.152400',
    region: 'Luzon',
    city: 'Rodriguez',
    tags: ['Rizal Highway', 'Authorized Outlet'],
    featured: false
  },

  // 21. Taytay Branch
  {
    id: 'store-21-taytay',
    storeName: 'Taytay Branch',
    lat: 14.561023,
    lng: 121.133201,
    address: '2/F Royale-V Bldg, 720 Rizal Ave, Dolores (Pob.), Taytay, Rizal 1920',
    phone: '9500574687',
    hours: 'Mon to Sat, 8:00 AM to 5:00 PM',
    image: 'https://static-maps.yandex.ru/1.x/?lang=en_US&ll=121.133201,14.561023&z=15&l=map&size=450,300&pt=121.133201,14.561023,pm2rdm',
    googleMapsLink: 'https://maps.google.com/?q=14.561023,121.133201',
    region: 'Luzon',
    city: 'Taytay',
    tags: ['Rizal Outlet', 'Authorized Outlet'],
    featured: false
  },

  // 22. Calamba Branch
  {
    id: 'store-22-calamba',
    storeName: 'Calamba Parian Branch',
    lat: 14.213557,
    lng: 121.144105,
    address: "Stall 1 Liana's Supermarket, Maharlika Hwy, end of Parian Rd, Parian, Calamba, Laguna 4027",
    phone: '9497228911',
    hours: 'Mon to Sun, 9:30 AM to 7:00 PM',
    image: 'https://static-maps.yandex.ru/1.x/?lang=en_US&ll=121.144105,14.213557&z=15&l=map&size=450,300&pt=121.144105,14.213557,pm2rdm',
    googleMapsLink: 'https://maps.google.com/?q=14.213557,121.144105',
    region: 'Luzon',
    city: 'Calamba',
    tags: ['Laguna Supermarket', 'Authorized Outlet'],
    featured: false
  },

  // 23. San Pedro Branch
  {
    id: 'store-23-sanpedro',
    storeName: 'San Pedro Branch',
    lat: 14.351296,
    lng: 121.054201,
    address: '2/F Gen Ber Bldg, Maharlika Hwy corner Barley Rd, San Vicente, San Pedro, Laguna 4023',
    phone: '9497228911',
    hours: 'Mon to Sat, 9:00 AM to 4:00 PM',
    image: 'https://static-maps.yandex.ru/1.x/?lang=en_US&ll=121.054201,14.351296&z=15&l=map&size=450,300&pt=121.054201,14.351296,pm2rdm',
    googleMapsLink: 'https://maps.google.com/?q=14.351296,121.054201',
    region: 'Luzon',
    city: 'San Pedro',
    tags: ['Laguna Outlet', 'Authorized Outlet'],
    featured: false
  },

  // 24. Sta. Cruz Branch
  {
    id: 'store-24-stacruz',
    storeName: 'Sta. Cruz Branch',
    lat: 14.278655,
    lng: 121.412105,
    address: 'Villa Josefina Subdivision, Quezon Ave, Calios, Santa Cruz, Laguna 4009',
    phone: '9497228911',
    hours: 'Mon to Sat, 9:00 AM to 4:00 PM',
    image: 'https://static-maps.yandex.ru/1.x/?lang=en_US&ll=121.412105,14.278655&z=15&l=map&size=450,300&pt=121.412105,14.278655,pm2rdm',
    googleMapsLink: 'https://maps.google.com/?q=14.278655,121.412105',
    region: 'Luzon',
    city: 'Santa Cruz',
    tags: ['Laguna Hub', 'Authorized Outlet'],
    featured: false
  },

  // 25. Quiapo Branch
  {
    id: 'store-25-quiapo',
    storeName: 'Quiapo Branch',
    lat: 14.597642,
    lng: 120.984201,
    address: 'Unit A G/F Mr. Mall, 339 Quezon Blvd, Quiapo, Manila, Metro Manila 1001',
    phone: '8735-5396 / 9190798169',
    hours: 'Mon to Sat, 8:00 AM to 5:00 PM',
    image: 'https://static-maps.yandex.ru/1.x/?lang=en_US&ll=120.984201,14.597642&z=15&l=map&size=450,300&pt=120.984201,14.597642,pm2rdm',
    googleMapsLink: 'https://maps.google.com/?q=14.597642,120.984201',
    region: 'Luzon',
    city: 'Manila',
    tags: ['Primary Outlet', 'Active Support', 'Manila Hub', 'Featured'],
    featured: true
  },

  // 26. Cebu Branch
  {
    id: 'store-26-cebu',
    storeName: 'Cebu Branch',
    lat: 10.318306,
    lng: 123.896304,
    address: 'Unit 1 Green Orkid, 78 N Escario St, Capitol Site, Cebu City, Cebu 6000',
    phone: '9619171258',
    hours: 'Mon to Sat, 8:00 AM to 5:00 PM',
    image: 'https://static-maps.yandex.ru/1.x/?lang=en_US&ll=123.896304,10.318306&z=15&l=map&size=450,300&pt=123.896304,10.318306,pm2rdm',
    googleMapsLink: 'https://maps.google.com/?q=10.318306,123.896304',
    region: 'Visayas',
    city: 'Cebu City',
    tags: ['Visayas Outpost', 'Primary Outlet', 'Cebu Hub', 'Featured'],
    featured: true
  },

  // 27. Malolos Branch
  {
    id: 'store-27-malolos',
    storeName: 'Malolos Branch',
    lat: 14.849895,
    lng: 120.812301,
    address: '2/F Trems/Avon Bldg, 66 Paseo del Congreso St, Catmon, Malolos, Bulacan 3000',
    phone: '9190816678 / 9299717360',
    hours: 'Mon to Sat, 8:00 AM to 5:00 PM',
    image: 'https://static-maps.yandex.ru/1.x/?lang=en_US&ll=120.812301,14.849895&z=15&l=map&size=450,300&pt=120.812301,14.849895,pm2rdm',
    googleMapsLink: 'https://maps.google.com/?q=14.849895,120.812301',
    region: 'Luzon',
    city: 'Malolos',
    tags: ['Bulacan Hub', 'Authorized Outlet'],
    featured: false
  },

  // 28. San Jose Tungko Branch
  {
    id: 'store-28-sanjose',
    storeName: 'San Jose Tungko Branch',
    lat: 14.787665,
    lng: 121.071101,
    address: '2/F Jumph Bldg, 30 Quirino Hwy, Tungkong Mangga, San Jose Del Monte, Bulacan 3023',
    phone: '9190816680',
    hours: 'Mon to Sat, 8:00 AM to 5:00 PM',
    image: 'https://static-maps.yandex.ru/1.x/?lang=en_US&ll=121.071101,14.787665&z=15&l=map&size=450,300&pt=121.071101,14.787665,pm2rdm',
    googleMapsLink: 'https://maps.google.com/?q=14.787665,121.071101',
    region: 'Luzon',
    city: 'San Jose Del Monte',
    tags: ['Bulacan Outlet', 'Authorized Outlet'],
    featured: false
  },

  // 29. Sta. Maria Branch
  {
    id: 'store-29-stamaria',
    storeName: 'Sta. Maria Branch',
    lat: 14.818328,
    lng: 120.962105,
    address: 'Unit 219 2/F Sta. Maria Town Center, 44 J.C. De Jesus St, Poblacion, Sta. Maria, Bulacan 3022',
    phone: '9190816679 / 9498039294',
    hours: 'Mon to Sat, 8:00 AM to 5:00 PM',
    image: 'https://static-maps.yandex.ru/1.x/?lang=en_US&ll=120.962105,14.818328&z=15&l=map&size=450,300&pt=120.962105,14.818328,pm2rdm',
    googleMapsLink: 'https://maps.google.com/?q=14.818328,120.962105',
    region: 'Luzon',
    city: 'Sta. Maria',
    tags: ['Bulacan Town Center', 'Authorized Outlet'],
    featured: false
  },

  // 30. Baclaran Branch
  {
    id: 'store-30-baclaran',
    storeName: 'Baclaran Branch',
    lat: 14.532251,
    lng: 120.992105,
    address: '2/F FPC Bldg, Redemptorist Rd corner Roxas Blvd Service Rd, Baclaran, Parañaque, Metro Manila 1702',
    phone: '9190816681 / 8853-1434',
    hours: 'Mon to Sat, 8:00 AM to 5:00 PM',
    image: 'https://static-maps.yandex.ru/1.x/?lang=en_US&ll=120.992105,14.532251&z=15&l=map&size=450,300&pt=120.992105,14.532251,pm2rdm',
    googleMapsLink: 'https://maps.google.com/?q=14.532251,120.992105',
    region: 'Luzon',
    city: 'Parañaque',
    tags: ['Redemptorist Hub', 'Primary Outlet', 'Metro Hub', 'Featured'],
    featured: true
  },

  // 31. Alabang Branch
  {
    id: 'store-31-alabang',
    storeName: 'Alabang Branch',
    lat: 14.418157,
    lng: 121.042105,
    address: 'Unit O 2/F KLC Bldg, Old West Service Rd, Alabang, Muntinlupa, Metro Manila 1799',
    phone: '9464941432',
    hours: 'Mon to Sat, 8:00 AM to 5:00 PM',
    image: 'https://static-maps.yandex.ru/1.x/?lang=en_US&ll=121.042105,14.418157&z=15&l=map&size=450,300&pt=121.042105,14.418157,pm2rdm',
    googleMapsLink: 'https://maps.google.com/?q=14.418157,121.042105',
    region: 'Luzon',
    city: 'Muntinlupa',
    tags: ['Muntinlupa Outlet', 'Authorized Outlet'],
    featured: false
  },

  // 32. Monumento Branch
  {
    id: 'store-32-monumento',
    storeName: 'Monumento Branch',
    lat: 14.657402,
    lng: 120.983905,
    address: 'G/F Bonifacio Market, Monumento Circle corner EDSA, Caloocan, Metro Manila 1400',
    phone: '9319962244 / 8366-4578',
    hours: 'Mon to Sat, 8:00 AM to 5:00 PM',
    image: 'https://static-maps.yandex.ru/1.x/?lang=en_US&ll=120.983905,14.657402&z=15&l=map&size=450,300&pt=120.983905,14.657402,pm2rdm',
    googleMapsLink: 'https://maps.google.com/?q=14.657402,120.983905',
    region: 'Luzon',
    city: 'Caloocan',
    tags: ['Monumento Circle', 'Primary Outlet', 'Featured'],
    featured: true
  },

  // 33. Novaliches Branch
  {
    id: 'store-33-novaliches',
    storeName: 'Novaliches Branch',
    lat: 14.717232,
    lng: 121.037105,
    address: '2/F Buenamar Dr corner General Luis St, Novaliches, Quezon City, Metro Manila 1123',
    phone: '9482416217 / 8722-3331',
    hours: 'Mon to Sat, 8:00 AM to 5:00 PM',
    image: 'https://static-maps.yandex.ru/1.x/?lang=en_US&ll=121.037105,14.717232&z=15&l=map&size=450,300&pt=121.037105,14.717232,pm2rdm',
    googleMapsLink: 'https://maps.google.com/?q=14.717232,121.037105',
    region: 'Luzon',
    city: 'Quezon City',
    tags: ['Novaliches Outlet', 'Authorized Outlet'],
    featured: false
  },

  // 34. Sta. Mesa Branch
  {
    id: 'store-34-stamesa',
    storeName: 'Sta. Mesa Branch',
    lat: 14.603624,
    lng: 121.012105,
    address: 'Stall T-009 Sta. Mesa Mart, Ramon Magsaysay Blvd, Manila, Metro Manila 1016',
    phone: '9161720574',
    hours: 'Mon to Sat, 8:00 AM to 5:00 PM',
    image: 'https://static-maps.yandex.ru/1.x/?lang=en_US&ll=121.012105,14.603624&z=15&l=map&size=450,300&pt=121.012105,14.603624,pm2rdm',
    googleMapsLink: 'https://maps.google.com/?q=14.603624,121.012105',
    region: 'Luzon',
    city: 'Manila',
    tags: ['Sta. Mesa Mart', 'Authorized Outlet'],
    featured: false
  },

  // 35. Valenzuela Branch
  {
    id: 'store-35-valenzuela',
    storeName: 'Valenzuela Branch',
    lat: 14.690799,
    lng: 120.978205,
    address: '281 MacArthur Hwy, Karuhatan, Valenzuela, Metro Manila 1441',
    phone: '9218723415 / 8567-3534',
    hours: 'Mon to Sat, 8:00 AM to 5:00 PM',
    image: 'https://static-maps.yandex.ru/1.x/?lang=en_US&ll=120.978205,14.690799&z=15&l=map&size=450,300&pt=120.978205,14.690799,pm2rdm',
    googleMapsLink: 'https://maps.google.com/?q=14.690799,120.978205',
    region: 'Luzon',
    city: 'Valenzuela',
    tags: ['Valenzuela Outlet', 'Authorized Outlet'],
    featured: false
  },

  // 36. Bicutan Branch
  {
    id: 'store-36-bicutan',
    storeName: 'Bicutan Branch',
    lat: 14.487024,
    lng: 121.041568,
    address: 'BS Square Commercial Inc., Doña Soledad Ave corner W Service Rd, Sun Valley, Parañaque, Metro Manila 1700',
    phone: '9190798171 / 9195409226',
    hours: 'Mon to Sat, 8:00 AM to 5:00 PM',
    image: 'https://static-maps.yandex.ru/1.x/?lang=en_US&ll=121.041568,14.487024&z=15&l=map&size=450,300&pt=121.041568,14.487024,pm2rdm',
    googleMapsLink: 'https://maps.google.com/?q=14.487024,121.041568',
    region: 'Luzon',
    city: 'Parañaque',
    tags: ['Bicutan Hub', 'Authorized Outlet'],
    featured: false
  },

  // 37. Guadalupe Branch
  {
    id: 'store-37-guadalupe',
    storeName: 'Guadalupe Branch',
    lat: 14.563932,
    lng: 121.045155,
    address: 'Unit B2 2/F GA Bldg, Manggahan St corner Ramon Magsaysay Ave, Guadalupe Nuevo, Makati, Metro Manila 1212',
    phone: '9190798170',
    hours: 'Mon to Sat, 8:00 AM to 5:00 PM',
    image: 'https://static-maps.yandex.ru/1.x/?lang=en_US&ll=121.045155,14.563932&z=15&l=map&size=450,300&pt=121.045155,14.563932,pm2rdm',
    googleMapsLink: 'https://maps.google.com/?q=14.563932,121.045155',
    region: 'Luzon',
    city: 'Makati',
    tags: ['Makati Hub', 'Authorized Outlet'],
    featured: false
  },

  // 38. Mandaluyong Crossing Branch
  {
    id: 'store-38-mandaluyong',
    storeName: 'Mandaluyong Crossing Branch',
    lat: 14.581568,
    lng: 121.053334,
    address: 'Parklea Centre, Shaw Blvd corner EDSA, Highway Hills, Mandaluyong, Metro Manila 1550',
    phone: '9098077205 / 9190798171',
    hours: 'Mon to Sat, 8:00 AM to 5:00 PM',
    image: 'https://static-maps.yandex.ru/1.x/?lang=en_US&ll=121.053334,14.581568&z=15&l=map&size=450,300&pt=121.053334,14.581568,pm2rdm',
    googleMapsLink: 'https://maps.google.com/?q=14.581568,121.053334',
    region: 'Luzon',
    city: 'Mandaluyong',
    tags: ['Transit Hub Junction', 'Authorized Outlet'],
    featured: false
  },

  // 39. Morong Branch
  {
    id: 'store-39-morong',
    storeName: 'Morong Branch',
    lat: 14.512105,
    lng: 121.238434,
    address: '2/F Tomas Claudio St, San Jose (Pob.), Morong, Rizal 1960',
    phone: '9277069240',
    hours: 'Mon to Sat, 8:00 AM to 5:00 PM',
    image: 'https://static-maps.yandex.ru/1.x/?lang=en_US&ll=121.238434,14.512105&z=15&l=map&size=450,300&pt=121.238434,14.512105,pm2rdm',
    googleMapsLink: 'https://maps.google.com/?q=14.512105,121.238434',
    region: 'Luzon',
    city: 'Morong',
    tags: ['Morong Outlet', 'Authorized Outlet'],
    featured: false
  },

  // 40. Tanay Branch
  {
    id: 'store-40-tanay',
    storeName: 'Tanay Branch',
    lat: 14.493554,
    lng: 121.280008,
    address: 'Stall #73 Bldg A Tanay Public Market, Plaza Aldea (Pob.), Tanay, Rizal 1980',
    phone: '9633403609 / 9354044281',
    hours: 'Mon to Sat, 8:00 AM to 5:00 PM',
    image: 'https://static-maps.yandex.ru/1.x/?lang=en_US&ll=121.280008,14.493554&z=15&l=map&size=450,300&pt=121.280008,14.493554,pm2rdm',
    googleMapsLink: 'https://maps.google.com/?q=14.493554,121.280008',
    region: 'Luzon',
    city: 'Tanay',
    tags: ['Tanay Market', 'Authorized Outlet'],
    featured: false
  },

  // 41. Malabon Branch
  {
    id: 'store-41-malabon',
    storeName: 'Malabon Branch',
    lat: 14.668078,
    lng: 120.948922,
    address: 'Sancti Josef Commercial Stalls, Inc., 213 Gov. Pascual Ave, Acacia, Malabon, Metro Manila 1470',
    phone: '9983407102',
    hours: 'Mon to Sat, 8:00 AM to 5:00 PM',
    image: 'https://static-maps.yandex.ru/1.x/?lang=en_US&ll=120.948922,14.668078&z=15&l=map&size=450,300&pt=120.948922,14.668078,pm2rdm',
    googleMapsLink: 'https://maps.google.com/?q=14.668078,120.948922',
    region: 'Luzon',
    city: 'Malabon',
    tags: ['Malabon Outlet', 'Authorized Outlet'],
    featured: false
  },

  // 42. North Caloocan Branch
  {
    id: 'store-42-northcaloocan',
    storeName: 'North Caloocan Branch',
    lat: 14.757155,
    lng: 121.038455,
    address: '2/F Caroline Bldg, 888 Camarin Rd, 178, North Caloocan, Caloocan, Metro Manila 1400',
    phone: '9308462221',
    hours: 'Mon to Sat, 8:00 AM to 5:00 PM',
    image: 'https://static-maps.yandex.ru/1.x/?lang=en_US&ll=121.038455,14.757155&z=15&l=map&size=450,300&pt=121.038455,14.757155,pm2rdm',
    googleMapsLink: 'https://maps.google.com/?q=14.757155,121.038455',
    region: 'Luzon',
    city: 'Caloocan',
    tags: ['Camarin Center', 'Authorized Outlet'],
    featured: false
  }
];

export function getStoredStores(): Store[] {
  // Use a bumped storage key to force reload the updated 42 locations
  const data = localStorage.getItem('herbenna_stores_v5');
  if (data) {
    try {
      return JSON.parse(data);
    } catch (e) {
      console.error('Error loading stores from localStorage, resetting data', e);
    }
  }
  return INITIAL_STORES;
}

export function saveStoresToStorage(stores: Store[]) {
  localStorage.setItem('herbenna_stores_v5', JSON.stringify(stores));
}
