/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, lazy, Suspense } from 'react';
import Header from './components/Header';
import StoreCard from './components/StoreCard';
import { Store } from './types';
import { getStoredStores, saveStoresToStorage, INITIAL_STORES } from './storesData';

// Lazy loaded components for code splitting & faster bundle parsing
const StoreMap = lazy(() => import('./components/StoreMap'));
const AdminPanel = lazy(() => import('./components/AdminPanel'));
import { 
  Search, 
  MapPin, 
  Compass, 
  Sparkles, 
  Sprout, 
  Map, 
  List, 
  X, 
  MessageSquare, 
  Globe, 
  Check, 
  Clock, 
  Navigation,
  ExternalLink,
  ChevronRight,
  Plus,
  Settings,
  ChevronDown,
  ChevronUp
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

// Optimized fallback placeholder skeleton loader for the Interactive Store Map
const MapLoaderFallback = () => (
  <div className="w-full h-full bg-brand-beige-200/50 rounded-3xl border border-stone-200/60 overflow-hidden flex flex-col items-center justify-center p-6 space-y-4 animate-pulse min-h-[420px] md:min-h-[500px]">
    <div className="p-3.5 bg-brand-green-100 rounded-full text-brand-green-700 shadow-inner">
      <Map className="w-10 h-10 text-brand-green-600 animate-[spin_3s_linear_infinite]" />
    </div>
    <div className="text-center space-y-2 max-w-xs">
      <div className="h-5 bg-stone-300 rounded-full w-3/4 mx-auto"></div>
      <div className="h-3.5 bg-stone-200 rounded-md w-1/2 mx-auto"></div>
    </div>
  </div>
);

// Optimized fallback placeholder skeleton loader for the Admin Sandbox panel
const AdminLoaderFallback = () => (
  <div className="w-full bg-white border border-stone-200 rounded-3xl p-6 h-64 animate-pulse flex flex-col justify-between">
    <div className="flex items-center space-x-3">
      <div className="w-10 h-10 bg-stone-200 rounded-xl animate-pulse"></div>
      <div className="space-y-2 flex-grow">
        <div className="h-4 bg-stone-350 rounded w-1/4"></div>
        <div className="h-3 bg-stone-250 rounded w-1/2"></div>
      </div>
    </div>
    <div className="space-y-2.5">
      <div className="h-4 bg-stone-100 rounded"></div>
      <div className="h-4 bg-stone-100 rounded"></div>
      <div className="h-4 bg-stone-100 rounded"></div>
    </div>
    <div className="flex justify-end space-x-3">
      <div className="w-16 h-8 bg-stone-100 rounded"></div>
      <div className="w-24 h-8 bg-stone-200 rounded"></div>
    </div>
  </div>
);

export default function App() {
  // Data State
  const [stores, setStores] = useState<Store[]>([]);
  const [selectedStore, setSelectedStore] = useState<Store | null>(null);
  const [hoveredStoreId, setHoveredStoreId] = useState<string | null>(null);

  // Filter States
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedRegion, setSelectedRegion] = useState<'All' | 'Luzon' | 'Visayas' | 'Mindanao'>('All');
  const [mapTheme, setMapTheme] = useState<'light' | 'warm' | 'dark'>('light');
  const [isDropdownOpen, setIsDropdownOpen] = useState(false);
  const [isSearchFocused, setIsSearchFocused] = useState(false);

  // Role/View Separation: Developer vs Customer
  const [isDeveloperMode, setIsDeveloperMode] = useState(false);
  const [isPasscodeModalOpen, setIsPasscodeModalOpen] = useState(false);
  const [passcode, setPasscode] = useState('');
  const [passcodeError, setPasscodeError] = useState(false);

  // Interface view states
  const [isAdminOpen, setIsAdminOpen] = useState(false);
  const [isFranchiseOpen, setIsFranchiseOpen] = useState(false);

  // Chatbot teaser state
  const [isChatOpen, setIsChatOpen] = useState(false);
  const [chatMessage, setChatMessage] = useState('');
  const [chatReplies, setChatReplies] = useState<{ sender: 'user' | 'bot'; text: string }[]>([
    { sender: 'bot', text: 'Mabuhay! Welcome to the Herbenna Interactive Locator Support system. I can list our active store addresses, directions, or guide you through editing controls.' }
  ]);

  // Geolocation Recommendation States
  const [userLocation, setUserLocation] = useState<{ lat: number; lng: number } | null>(null);
  const [locationLoading, setLocationLoading] = useState(false);
  const [locationError, setLocationError] = useState<string | null>(null);
  const [nearestStore, setNearestStore] = useState<{ store: Store; distance: number } | null>(null);
  const [hasScannedLocation, setHasScannedLocation] = useState(false);

  // Helper distance function (Haversine Formula) (in km)
  const calculateDistance = (lat1: number, lon1: number, lat2: number, lon2: number): number => {
    const R = 6371; // Radius of the Earth in km
    const dLat = (lat2 - lat1) * Math.PI / 180;
    const dLon = (lon2 - lon1) * Math.PI / 180;
    const a = 
      Math.sin(dLat / 2) * Math.sin(dLat / 2) +
      Math.cos(lat1 * Math.PI / 180) * Math.cos(lat2 * Math.PI / 180) * 
      Math.sin(dLon / 2) * Math.sin(dLon / 2);
    const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
    return parseFloat((R * c).toFixed(1)); // Rounded to 1 decimal place
  };

  const locateUserAndRecommend = (autoScroll = false) => {
    if (!navigator.geolocation) {
      setLocationError("Geolocation is not supported by your browser.");
      setHasScannedLocation(true);
      return;
    }

    setLocationLoading(true);
    setLocationError(null);

    navigator.geolocation.getCurrentPosition(
      (position) => {
        const { latitude, longitude } = position.coords;
        setUserLocation({ lat: latitude, lng: longitude });
        setLocationLoading(false);
        setHasScannedLocation(true);

        // Compute closest store from all stores
        const currentStores = stores.length > 0 ? stores : getStoredStores();
        if (currentStores.length > 0) {
          let closestStore: Store | null = null;
          let minDistance = Infinity;

          currentStores.forEach((store) => {
            const dist = calculateDistance(latitude, longitude, store.lat, store.lng);
            if (dist < minDistance) {
              minDistance = dist;
              closestStore = store;
            }
          });

          if (closestStore) {
            setNearestStore({ store: closestStore, distance: minDistance });
            setSelectedStore(closestStore); // Select the recommended store on map & side list
            
            if (autoScroll) {
              setTimeout(() => {
                const locatorSection = document.getElementById('locator');
                if (locatorSection) {
                  locatorSection.scrollIntoView({ behavior: 'smooth', block: 'start' });
                }
              }, 100);
            }
          }
        }
      },
      (error) => {
        setLocationLoading(false);
        setHasScannedLocation(true);
        switch (error.code) {
          case error.PERMISSION_DENIED:
            setLocationError("Location access denied. Please allow location permissions to see recommendations.");
            break;
          case error.POSITION_UNAVAILABLE:
            setLocationError("Your position could not be determined. Try searching for a city manually.");
            break;
          case error.TIMEOUT:
            setLocationError("Location request timed out. Please try again.");
            break;
          default:
            setLocationError("Could not retrieve current location.");
            break;
        }
      },
      { enableHighAccuracy: true, timeout: 8000, maximumAge: 0 }
    );
  };

  // Check location permission on mount / when stores load
  useEffect(() => {
    if (navigator.permissions && navigator.geolocation) {
      navigator.permissions.query({ name: 'geolocation' as PermissionName }).then((status) => {
        if (status.state === 'granted') {
          locateUserAndRecommend(false);
        }
      }).catch((e) => {
        console.log("Permission query check bypassed default settings", e);
      });
    }
  }, [stores]);

  // Load stores from storage on mount & check URL / LocalStorage for dev mode
  useEffect(() => {
    const loadedStores = getStoredStores();
    setStores(loadedStores);
    
    // Default select Flagship Quiapo store on load
    const flagship = loadedStores.find(s => s.id === 'store-quiapo');
    if (flagship) {
      setSelectedStore(flagship);
    } else if (loadedStores.length > 0) {
      setSelectedStore(loadedStores[0]);
    }

    // Auto-detect Dev mode from session storage or URL query
    const isDev = localStorage.getItem('herbenna_dev_session') === 'true';
    const urlParams = new URLSearchParams(window.location.search);
    if (isDev || urlParams.get('mode') === 'developer' || urlParams.get('dev') === 'true') {
      setIsDeveloperMode(true);
      setIsAdminOpen(true);
    }
  }, []);

  // Filtered Stores logic
  const filteredStores = stores.filter((store) => {
    const matchesSearch =
      store.storeName.toLowerCase().includes(searchQuery.toLowerCase()) ||
      store.city.toLowerCase().includes(searchQuery.toLowerCase()) ||
      store.address.toLowerCase().includes(searchQuery.toLowerCase()) ||
      (store.tags && store.tags.some(tag => tag.toLowerCase().includes(searchQuery.toLowerCase())));

    const matchesRegion = selectedRegion === 'All' || store.region === selectedRegion;

    return matchesSearch && matchesRegion;
  });

  // Admin CRUD ops
  const handleAddStore = (newStoreData: Omit<Store, 'id'>) => {
    const newStore: Store = {
      id: `store-${Date.now()}`,
      ...newStoreData
    };
    const updated = [...stores, newStore];
    setStores(updated);
    saveStoresToStorage(updated);
    setSelectedStore(newStore); // Automatically focus newly created store
  };

  const handleUpdateStore = (updatedStore: Store) => {
    const updated = stores.map(s => s.id === updatedStore.id ? updatedStore : s);
    setStores(updated);
    saveStoresToStorage(updated);
    setSelectedStore(updatedStore); // Focus updated store
  };

  const handleDeleteStore = (id: string) => {
    const updated = stores.filter(s => s.id !== id);
    setStores(updated);
    saveStoresToStorage(updated);
    if (selectedStore?.id === id) {
      setSelectedStore(updated.length > 0 ? updated[0] : null);
    }
  };

  // ChatBot submit
  const handleChatSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!chatMessage.trim()) return;

    const userMsg = chatMessage;
    const history = [...chatReplies, { sender: 'user' as const, text: userMsg }];
    setChatReplies(history);
    setChatMessage('');

    setTimeout(() => {
      let botResponse = "I am mapping out your wellness options. For live support or store queries, you can talk to us or visit our active Luzon branches!";
      const query = userMsg.toLowerCase();
      
      if (query.includes('store') || query.includes('where') || query.includes('locate') || query.includes('branch')) {
        botResponse = `We currently have ${stores.length} authorized branches actively registered in our system. Try searching by city or branch name in our interactive locator directory above!`;
      } else if (query.includes('franchise') || query.includes('partner') || query.includes('own')) {
        botResponse = "Herbenna runs official licensing and cooperative partnership ventures. Use our support channels for enterprise inquiries!";
      } else if (query.includes('moringa') || query.includes('serum') || query.includes('oil')) {
        botResponse = "Our organic health formulations are fully stocked across our active retail branches. Contact a branch manager directly for details!";
      } else if (query.includes('hours') || query.includes('time') || query.includes('open')) {
        botResponse = "Our physical branches operate according to the schedules posted in the directory listing. Select any branch to view accurate hours!";
      }

      setChatReplies([...history, { sender: 'bot' as const, text: botResponse }]);
    }, 800);
  };

  // Passcode submit handler to unlock Developer view
  const handlePasscodeSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const normalized = passcode.trim().toLowerCase();
    if (normalized === 'herbenna' || normalized === 'admin') {
      setIsDeveloperMode(true);
      setIsAdminOpen(true);
      localStorage.setItem('herbenna_dev_session', 'true');
      setIsPasscodeModalOpen(false);
      setPasscode('');
      setPasscodeError(false);
      setTimeout(() => {
        handleLocateStoreCTA();
      }, 100);
    } else {
      setPasscodeError(true);
    }
  };

  // Nav scroll triggers
  const handleLocateStoreCTA = () => {
    const locatorSection = document.getElementById('locator');
    if (locatorSection) {
      locatorSection.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }
    // Automatically trigger proximity scan
    locateUserAndRecommend(false);
  };

  return (
    <div className="min-h-screen bg-[#fcfaf2] text-stone-800 font-sans leading-relaxed selection:bg-brand-green-100 selection:text-brand-green-800">
      
      {/* 1. Brand Navigation Header */}
      <Header
        onAdminToggle={() => setIsAdminOpen(!isAdminOpen)}
        isAdminOpen={isAdminOpen}
        mapTheme={mapTheme}
        setMapTheme={setMapTheme}
        isDeveloperMode={isDeveloperMode}
        onExitDeveloper={() => {
          setIsDeveloperMode(false);
          setIsAdminOpen(false);
          localStorage.removeItem('herbenna_dev_session');
        }}
        onEnterDeveloper={() => {
          setIsPasscodeModalOpen(true);
        }}
      />

      {/* 2. Core Store Locator Sandbox Container */}
      <section id="locator" className="py-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Dynamic Admin Portal panel expand */}
        {isAdminOpen && (
          <div className="mb-8">
            <Suspense fallback={<AdminLoaderFallback />}>
              <AdminPanel
                stores={stores}
                onAddStore={handleAddStore}
                onUpdateStore={handleUpdateStore}
                onDeleteStore={handleDeleteStore}
                onClose={() => setIsAdminOpen(false)}
              />
            </Suspense>
          </div>
        )}

        {/* Filters and Controls Interface */}
        <div className="bg-white border border-stone-200 rounded-3xl p-6 shadow-sm mb-8 space-y-6">
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
            {/* Headers titles */}
            <div>
              <div className="flex items-center space-x-1 text-brand-green-700 mb-1">
                <Compass className="w-5 h-5" />
                <span className="text-xs uppercase font-bold tracking-widest">National Outlets Map</span>
              </div>
              <h2 className="font-heading font-semibold text-2xl text-stone-900">
                Explore Registered Outlets
              </h2>
              <p className="text-xs text-stone-500 mt-0.5">
                Refine by island territory or search for cities to load directions instantly.
              </p>
            </div>
          </div>

          <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-4">
            {/* Real Search inputs bar */}
            <div className="flex-1 relative">
              <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4.5 h-4.5 text-stone-400" />
              <input
                type="text"
                value={searchQuery}
                onFocus={() => setIsSearchFocused(true)}
                onBlur={() => setTimeout(() => setIsSearchFocused(false), 200)}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Search by city, store name, or wellness tag..."
                className="w-full pl-10 pr-4 py-3 border border-stone-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-brand-green-600 focus:border-stone-300 text-sm bg-stone-50 text-stone-800 placeholder-stone-400"
              />
              {searchQuery && (
                <button
                  onClick={() => setSearchQuery('')}
                  className="absolute right-3.5 top-1/2 -translate-y-1/2 p-0.5 hover:bg-stone-200 rounded-full text-stone-400 transition-colors"
                >
                  <X className="w-3.5 h-3.5" />
                </button>
              )}

              {/* Real-time search suggestions dropdown */}
              {searchQuery && isSearchFocused && (
                <div className="absolute left-0 right-0 top-full mt-2 bg-white border border-stone-200 rounded-2xl shadow-xl overflow-hidden z-50 max-h-[280px] overflow-y-auto">
                  <div className="p-2 divide-y divide-stone-100">
                    <div className="px-3 py-1.5 text-[10px] font-bold text-stone-400 uppercase tracking-wider">
                      Matched Suggestions ({filteredStores.length})
                    </div>
                    {filteredStores.slice(0, 5).map((store) => (
                      <button
                        key={store.id}
                        type="button"
                        onMouseDown={() => {
                          setSelectedStore(store);
                          if (selectedRegion !== 'All' && store.region !== selectedRegion) {
                            setSelectedRegion('All');
                          }
                        }}
                        onMouseEnter={() => setHoveredStoreId(store.id)}
                        onMouseLeave={() => setHoveredStoreId(null)}
                        className="w-full flex items-center justify-between px-3 py-3 hover:bg-brand-green-50/50 text-left text-xs transition-colors cursor-pointer group"
                      >
                        <div className="flex items-center space-x-2.5 truncate">
                          <MapPin className="w-4 h-4 text-brand-green-600 group-hover:text-brand-green-800 flex-shrink-0" />
                          <div className="truncate">
                            <span className="font-semibold text-stone-900 block truncate group-hover:text-brand-green-900">
                              {store.storeName}
                            </span>
                            <span className="text-[10px] text-stone-500 block truncate">
                              {store.address}
                            </span>
                          </div>
                        </div>
                        <span className="text-[10px] text-stone-400 bg-stone-100 group-hover:bg-brand-green-100/50 group-hover:text-brand-green-900 px-2 py-0.5 rounded font-sans flex-shrink-0 ml-2">
                          {store.city} ({store.region})
                        </span>
                      </button>
                    ))}
                    {filteredStores.length === 0 && (
                      <div className="py-6 text-center text-xs text-stone-400 font-sans italic">
                        No authorized outlets match "{searchQuery}"
                      </div>
                    )}
                  </div>
                </div>
              )}
            </div>

            {isDeveloperMode && (
              <button
                onClick={() => setIsAdminOpen(!isAdminOpen)}
                className={`flex-shrink-0 px-4 py-2.5 rounded-xl text-xs font-bold tracking-wide transition-all border cursor-pointer flex items-center justify-center space-x-1.5 shadow-sm hover:scale-[1.01] ${
                  isAdminOpen
                    ? 'bg-amber-600 border-amber-600 text-white'
                    : 'bg-amber-50 border-amber-200 text-amber-800 hover:bg-amber-100/80'
                }`}
              >
                <Settings className={`w-3.5 h-3.5 ${isAdminOpen ? 'animate-spin' : ''}`} />
                <span>{isAdminOpen ? 'Close Developer Desk' : 'Open Developer Desk'}</span>
              </button>
            )}
          </div>

          {/* Dynamic store count alerts banner */}
          <div className="flex flex-wrap items-center justify-between text-xs text-stone-500 bg-stone-50 p-3 rounded-xl border border-stone-100">
            <div className="flex items-center space-x-1.5">
              <span className="w-2 h-2 rounded-full bg-brand-green-600 anim-pulse"></span>
              <span>Showing <strong>{filteredStores.length}</strong> outlets matching filters in <strong>Luzon, PH</strong></span>
            </div>
            {selectedStore && (
              <span className="hidden sm:inline">Active: <strong className="text-brand-green-800">{selectedStore.storeName}</strong> ({selectedStore.city})</span>
            )}
          </div>
        </div>

        {/* Near Store Recommendation System */}
        <AnimatePresence>
          <motion.div
            initial={{ opacity: 0, y: -10 }}
            animate={{ opacity: 1, y: 0 }}
            className="mb-8 border border-stone-200 bg-white rounded-3xl p-6 shadow-sm overflow-hidden"
          >
            <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-6">
              <div className="flex items-start space-x-4 flex-1">
                <div className="p-3 bg-brand-green-100 rounded-2xl text-brand-green-700 mt-1 sm:mt-0 flex-shrink-0 animate-pulse">
                  <Compass className="w-6 h-6" />
                </div>
                <div className="space-y-1">
                  <div className="flex items-center flex-wrap gap-2">
                    <span className="text-[10px] bg-brand-green-600 text-white font-bold px-2.5 py-1 rounded-full uppercase tracking-wider whitespace-nowrap">
                      Location Guide
                    </span>
                    {userLocation && (
                      <span className="text-[10px] bg-emerald-100 text-emerald-800 font-bold px-2.5 py-1 rounded-full uppercase tracking-wider flex items-center gap-1 whitespace-nowrap">
                        <Check className="w-3 h-3 flex-shrink-0" /> GPS Connected
                      </span>
                    )}
                  </div>
                  <h3 className="font-heading font-semibold text-lg text-stone-900">
                    {locationLoading 
                      ? "Searching Nearest Branch..." 
                      : nearestStore 
                        ? `Closest Outlet Found: ${nearestStore.store.storeName}` 
                        : "Discover Authorised Outlets Near You"
                    }
                  </h3>
                  
                  {/* Status descriptions */}
                  {locationLoading && (
                    <p className="text-xs text-stone-500 animate-pulse">
                      Consulting network coordinates to match the nearest Herbenna health stores to your current location...
                    </p>
                  )}

                  {!locationLoading && !nearestStore && !locationError && (
                    <p className="text-xs text-stone-500 leading-relaxed max-w-2xl">
                      Visiting our page? Allow location security permissions to instantly map and highlight the nearest authorized Herbenna branch, check operating hours, and claim direct driving directions.
                    </p>
                  )}

                  {!locationLoading && nearestStore && (
                    <div className="space-y-2">
                      <p className="text-xs text-stone-605 leading-relaxed max-w-2xl">
                        Based on your approximate GPS position, the closest branch is the <strong className="text-brand-green-700">{nearestStore.store.storeName}</strong>, located approximately <strong className="text-brand-green-600 bg-brand-green-50 px-1.5 py-0.5 rounded text-sm">{nearestStore.distance} km</strong> away in <strong className="text-stone-850">{nearestStore.store.city}</strong>.
                      </p>
                      <p className="text-[11px] text-stone-400 font-sans italic flex items-center gap-1.5">
                        <Clock className="w-3 h-3 text-stone-400" /> Operating hours: {nearestStore.store.hours} • Phone: {nearestStore.store.phone || "N/A"}
                      </p>
                    </div>
                  )}

                  {!locationLoading && locationError && (
                    <p className="text-xs text-amber-700 font-semibold bg-amber-50 border border-amber-100 px-3 py-2 rounded-xl">
                      ⚠️ {locationError}
                    </p>
                  )}
                </div>
              </div>

              {/* Action buttons wrapper */}
              <div className="flex flex-wrap items-center gap-3 w-full md:w-auto self-stretch md:self-center justify-end">
                {locationLoading ? (
                  <div className="flex items-center space-x-2 text-stone-500 text-xs font-semibold px-4 py-2 bg-stone-100 rounded-xl animate-pulse">
                    <span className="w-3 h-3 border-2 border-stone-400 border-t-stone-200 rounded-full animate-spin"></span>
                    <span>Locating...</span>
                  </div>
                ) : nearestStore ? (
                  <>
                    <button
                      onClick={() => {
                        setSelectedStore(nearestStore.store);
                        const locatorSection = document.getElementById('locator');
                        if (locatorSection) {
                          locatorSection.scrollIntoView({ behavior: 'smooth', block: 'start' });
                        }
                      }}
                      className="flex-1 sm:flex-initial bg-brand-green-700 hover:bg-brand-green-800 text-white font-bold text-xs px-5 py-3 rounded-xl shadow-md cursor-pointer transition-colors flex items-center justify-center gap-1.5"
                    >
                      <MapPin className="w-3.5 h-3.5 text-white" />
                      <span>Focus on Map</span>
                    </button>
                    <a
                      href={nearestStore.store.googleMapsLink}
                      target="_blank"
                      rel="noreferrer"
                      className="flex-1 sm:flex-initial bg-emerald-100 hover:bg-emerald-200 text-emerald-800 font-bold text-xs px-5 py-3 rounded-xl border border-emerald-200 cursor-pointer transition-colors text-center flex items-center justify-center gap-1.5"
                    >
                      <ExternalLink className="w-3.5 h-3.5" />
                      <span>Get Directions</span>
                    </a>
                    <button
                      onClick={() => locateUserAndRecommend(true)}
                      title="Recalculate proximity"
                      className="p-3 bg-stone-100 hover:bg-stone-200 rounded-xl text-stone-500 cursor-pointer transition-colors flex items-center justify-center"
                    >
                      <Compass className="w-4 h-4 animate-spin-slow" />
                    </button>
                  </>
                ) : (
                  <button
                    onClick={() => locateUserAndRecommend(true)}
                    className="w-full sm:w-auto bg-brand-green-700 hover:bg-brand-green-800 text-white font-bold text-xs px-6 py-3.5 rounded-xl shadow-lg hover:shadow-brand-green-700/20 active:scale-[0.99] transition-all flex items-center justify-center space-x-2 cursor-pointer"
                  >
                    <Compass className="w-4 h-4 text-brand-green-100" />
                    <span>Recommend Nearest Store</span>
                  </button>
                )}
              </div>
            </div>
          </motion.div>
        </AnimatePresence>

        {/* Master Locator Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start h-auto lg:h-[680px]">
          
          {/* Left panel: Stores listings */}
          <div className="col-span-1 lg:col-span-5 h-auto lg:h-full flex flex-col space-y-4">
            <div className="text-xs font-bold uppercase tracking-wider text-stone-400 flex items-center justify-between">
              <span>National Network Directory</span>
              <span className="text-[10px] bg-brand-green-500/10 text-brand-green-800 px-2.5 py-0.5 rounded-full font-bold">
                PH Archipelago Base Map
              </span>
            </div>

            {/* Custom Premium Dropdown Selector */}
            <div className="relative">
              <button
                type="button"
                onClick={() => setIsDropdownOpen(!isDropdownOpen)}
                className="w-full flex items-center justify-between bg-white border border-stone-200 hover:border-brand-green-650 px-4 py-3.5 rounded-2xl shadow-sm text-left text-sm cursor-pointer transition-colors focus:outline-none focus:ring-2 focus:ring-brand-green-500/20 relative z-30"
              >
                <div className="flex items-center space-x-2.5 truncate">
                  <div className="w-2.5 h-2.5 rounded-full bg-brand-green-600 animate-pulse flex-shrink-0" />
                  <span className="font-semibold text-stone-900 truncate">
                    {selectedStore ? `${selectedStore.storeName} (${selectedStore.city})` : 'Select an active branch...'}
                  </span>
                </div>
                {isDropdownOpen ? (
                  <ChevronUp className="w-4 h-4 text-stone-505 ml-2" />
                ) : (
                  <ChevronDown className="w-4 h-4 text-stone-505 ml-2" />
                )}
              </button>

              {/* Popover list */}
              {isDropdownOpen && (
                <>
                  <div 
                    className="fixed inset-0 z-20 cursor-default" 
                    onClick={() => setIsDropdownOpen(false)}
                  />
                  <div className="absolute left-0 right-0 mt-2 bg-white border border-stone-200 rounded-2xl shadow-xl overflow-hidden z-30 flex flex-col max-h-[320px]">
                    {/* Inline search filter */}
                    <div className="p-3 border-b border-stone-100 bg-stone-50/50">
                      <div className="relative">
                        <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-stone-400" />
                        <input
                          type="text"
                          value={searchQuery}
                          onChange={(e) => setSearchQuery(e.target.value)}
                          placeholder="Type to filter branches..."
                          className="w-full pl-9 pr-8 py-2 bg-white border border-stone-200 rounded-xl focus:outline-none focus:ring-1 focus:ring-brand-green-500 text-xs text-stone-800"
                          onClick={(e) => e.stopPropagation()} // stop click-to-close dropdown trigger
                        />
                        {searchQuery && (
                          <button
                            type="button"
                            onClick={(e) => { e.stopPropagation(); setSearchQuery(''); }}
                            className="absolute right-3 top-1/2 -translate-y-1/2 p-0.5 hover:bg-stone-250 rounded-full text-stone-400"
                          >
                            <X className="w-3 h-3" />
                          </button>
                        )}
                      </div>
                    </div>

                    {/* Options list, grouped by region */}
                    <div className="overflow-y-auto scrollbar-thin divide-y divide-stone-100/50">
                      {['Luzon', 'Visayas', 'Mindanao'].map((reg) => {
                        const regionStores = filteredStores.filter(s => s.region === reg);
                        if (regionStores.length === 0) return null;
                        return (
                          <div key={reg} className="p-1">
                            <div className="px-3 py-1.5 text-[9px] font-black uppercase tracking-widest text-brand-green-800 bg-brand-green-50/50 rounded-lg">
                              {reg} island group
                            </div>
                            <div className="mt-1 space-y-0.5">
                              {regionStores.map((store) => (
                                <button
                                  key={store.id}
                                  type="button"
                                  onClick={() => {
                                    setSelectedStore(store);
                                    setIsDropdownOpen(false);
                                  }}
                                  onMouseEnter={() => setHoveredStoreId(store.id)}
                                  onMouseLeave={() => setHoveredStoreId(null)}
                                  className={`w-full flex items-center justify-between px-3 py-2 rounded-xl text-left text-xs transition-colors cursor-pointer ${
                                    selectedStore?.id === store.id
                                      ? 'bg-brand-green-50 text-brand-green-900 font-bold'
                                      : 'hover:bg-stone-50 text-stone-700'
                                  }`}
                                >
                                  <div className="flex items-center space-x-2 truncate">
                                    <MapPin className={`w-3.5 h-3.5 flex-shrink-0 ${
                                      selectedStore?.id === store.id ? 'text-brand-green-600' : 'text-stone-400'
                                    }`} />
                                    <span className="truncate">{store.storeName}</span>
                                  </div>
                                  <span className="text-[10px] text-stone-400 bg-stone-100/60 px-1.5 py-0.5 rounded font-sans flex-shrink-0 ml-2">
                                    {store.city}
                                  </span>
                                </button>
                              ))}
                            </div>
                          </div>
                        );
                      })}

                      {filteredStores.length === 0 && (
                        <div className="py-8 text-center text-xs text-stone-400 font-sans">
                          No active branches match your search criteria.
                        </div>
                      )}
                    </div>
                  </div>
                </>
              )}
            </div>

            {/* Selected Store Detailed Highlight Option */}
            <div className="flex-1 overflow-y-auto space-y-4 pr-1">
              {selectedStore ? (
                <div className="space-y-3">
                  <div className="text-[10px] text-stone-400 font-bold uppercase tracking-wider pl-1 flex items-center justify-between">
                    <span>Selected Outlet Highlights</span>
                    {selectedStore.region && (
                      <span className="text-brand-green-700 bg-brand-green-50 px-2 py-0.5 rounded font-sans text-[10px] font-bold">
                        {selectedStore.region} division
                      </span>
                    )}
                  </div>
                  <StoreCard
                    store={selectedStore}
                    isSelected={true}
                    onSelect={() => {}}
                    onGetDirections={() => {
                      window.open(selectedStore.googleMapsLink, '_blank', 'noreferrer');
                    }}
                    onMouseEnter={() => setHoveredStoreId(selectedStore.id)}
                    onMouseLeave={() => setHoveredStoreId(null)}
                  />
                </div>
              ) : filteredStores.length > 0 ? (
                <div className="space-y-3">
                  <div className="text-[10px] text-stone-400 font-bold tracking-wider pl-1 uppercase">
                    Suggesting first matched outlet
                  </div>
                  <StoreCard
                    store={filteredStores[0]}
                    isSelected={true}
                    onSelect={() => setSelectedStore(filteredStores[0])}
                    onGetDirections={() => {
                      window.open(filteredStores[0].googleMapsLink, '_blank', 'noreferrer');
                    }}
                    onMouseEnter={() => setHoveredStoreId(filteredStores[0].id)}
                    onMouseLeave={() => setHoveredStoreId(null)}
                  />
                </div>
              ) : (
                <div className="bg-white border border-stone-200 rounded-3xl p-12 text-center space-y-3">
                  <div className="w-12 h-12 bg-stone-50 text-stone-400 rounded-full flex items-center justify-center mx-auto border border-stone-100">
                    <Search className="w-6 h-6" />
                  </div>
                  <h4 className="font-heading font-semibold text-stone-900 text-sm">No Branches Found</h4>
                  <p className="text-xs text-stone-500 max-w-xs mx-auto">
                    Try clearing search inputs or toggling another Philippines island territory filter above.
                  </p>
                  <button
                    onClick={() => { setSearchQuery(''); setSelectedRegion('All'); }}
                    className="bg-brand-green-700 hover:bg-brand-green-800 text-white font-bold text-xs py-2 px-4 rounded-xl shadow-md transition-colors"
                  >
                    Reset Directory filters
                  </button>
                </div>
              )}
            </div>
          </div>

          {/* Right panel: Full screen Interactive map */}
          <div className="col-span-1 lg:col-span-7 h-[420px] md:h-[500px] lg:h-full relative block">
            <Suspense fallback={<MapLoaderFallback />}>
              <StoreMap
                stores={filteredStores}
                selectedStore={selectedStore}
                onStoreSelect={setSelectedStore}
                mapTheme={mapTheme}
                hoveredStoreId={hoveredStoreId}
                onStoreHover={setHoveredStoreId}
              />
            </Suspense>
          </div>

        </div>

      </section>

      {/* 5. Sticky Float Triggers and chat support removed */}



      {/* 9. Secure Passcode verification Modal */}
      <AnimatePresence>
        {isPasscodeModalOpen && (
          <div className="fixed inset-0 z-[100] flex items-center justify-center p-4">
            {/* Backdrop shadow overlay */}
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => {
                setIsPasscodeModalOpen(false);
                setPasscode('');
                setPasscodeError(false);
              }}
              className="absolute inset-0 bg-stone-950/60 backdrop-blur-md"
            />

            {/* Modal Card frame */}
            <motion.div
              initial={{ opacity: 0, scale: 0.95, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95, y: 20 }}
              className="relative w-full max-w-sm bg-white border border-stone-200 shadow-2xl rounded-3xl overflow-hidden z-10 p-6 md:p-8"
            >
              <div className="space-y-4">
                <div className="w-12 h-12 bg-amber-50 text-amber-600 rounded-full flex items-center justify-center border border-amber-100">
                  <Settings className="w-6 h-6 animate-spin-slow" />
                </div>
                
                <div>
                  <h3 className="font-heading font-semibold text-lg text-stone-900">Developer Desk Authentication</h3>
                  <p className="text-xs text-stone-500 mt-1">
                    Please enter the authorization passcode to enable real-time map controls and coordinate editing features.
                  </p>
                </div>

                <form onSubmit={handlePasscodeSubmit} className="space-y-4 pt-2">
                  <div>
                    <label className="block text-[10px] font-bold uppercase tracking-wider text-stone-400 mb-1.5">
                      Security Passcode
                    </label>
                    <input
                      type="password"
                      value={passcode}
                      onChange={(e) => {
                        setPasscode(e.target.value);
                        setPasscodeError(false);
                      }}
                      placeholder="Enter security code..."
                      className={`w-full px-4 py-3 border rounded-xl focus:outline-none focus:ring-2 focus:ring-brand-green-600 text-xs ${
                        passcodeError
                          ? 'border-red-300 bg-red-50 text-red-900 focus:ring-red-500'
                          : 'border-stone-200 bg-stone-50 text-stone-800'
                      }`}
                      autoFocus
                    />
                    {passcodeError && (
                      <p className="text-xs text-red-600 font-semibold mt-1">
                        Incorrect security passcode.
                      </p>
                    )}
                  </div>

                  <div className="flex items-center justify-end space-x-3 pt-2">
                    <button
                      type="button"
                      onClick={() => {
                        setIsPasscodeModalOpen(false);
                        setPasscode('');
                        setPasscodeError(false);
                      }}
                      className="px-4 py-2.5 rounded-xl text-xs font-semibold hover:bg-stone-100 text-stone-600 transition-colors cursor-pointer"
                    >
                      Cancel
                    </button>
                    <button
                      type="submit"
                      className="bg-brand-green-700 hover:bg-brand-green-800 text-white font-semibold text-xs px-5 py-2.5 rounded-xl shadow-md transition-colors cursor-pointer"
                    >
                      Verify Passcode
                    </button>
                  </div>
                </form>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

    </div>
  );

  // Helper scroll/location focus
  function handleLocateUserClick() {
    handleLocateStoreCTA();
  }
}
